import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  Search, 
  Bell, 
  BookOpen, 
  PhoneCall, 
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
  Users,
  Calendar,
  Monitor
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { getSettings, getNotices, getGallery } from '../services/api';
import { SiteSettings, Notice, GalleryItem } from '../types';
import { format } from 'date-fns';
import { getDirectImageUrl } from '../lib/imageUtils';

const Home = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);

  const defaultSlides = [
    {
      image: settings?.bannerUrl ? getDirectImageUrl(settings.bannerUrl) : "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=2000&auto=format&fit=crop",
      title: "শিক্ষাই জাতির মেরুদণ্ড",
      subtitle: "সুস্থ, সুন্দর ও আলোকিত ভবিষ্যৎ গড়তে আমরা প্রতিজ্ঞাবদ্ধ।"
    },
    {
      image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=2000&auto=format&fit=crop",
      title: "বিদ্যা অমূল্য ধন",
      subtitle: "জ্ঞানের আলোয় দূর হোক অন্ধকারের কালো ছায়া।"
    },
    {
      image: "https://images.unsplash.com/photo-1497633275055-38e0365f50ea?q=80&w=2000&auto=format&fit=crop",
      title: "ছাত্রনং অধ্যয়নং তপঃ",
      subtitle: "মনোযোগ সহকারে অধ্যয়নই ছাত্র জীবনের মূল আদর্শ।"
    },
    {
      image: "https://images.unsplash.com/photo-1524178232363-1fb28f74b0cd?q=80&w=2000&auto=format&fit=crop",
      title: "জ্ঞানের আলোয় আলোকিত হোক জীবন",
      subtitle: "শিক্ষার অধিকার, উন্নয়নের চমৎকার হাতিয়ার।"
    },
    {
      image: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?q=80&w=2000&auto=format&fit=crop",
      title: "শিখুন এবং বড় হোন",
      subtitle: "সৃজনশীল শিক্ষার মাধ্যমে আগামী দিনের নেতৃত্ব তৈরি করছি আমরা।"
    }
  ];

  const slides = settings?.heroSlides && settings.heroSlides.length > 0 
    ? settings.heroSlides.map(s => ({ ...s, image: getDirectImageUrl(s.image) })) 
    : defaultSlides;

  useEffect(() => {
    const fetchData = async () => {
      const [s, n, g] = await Promise.all([getSettings(), getNotices(), getGallery()]);
      setSettings(s);
      setNotices(n);
      setGallery(g.slice(0, 4));
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (slides.length > 0) {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
      }, 5000);
      return () => clearInterval(timer);
    }
  }, [slides.length]);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

  const bannerSrc = settings?.bannerUrl ? getDirectImageUrl(settings.bannerUrl) : "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=2000&auto=format&fit=crop";

  return (
    <div className="bg-gray-50 pb-12">
      {/* Hero Slider Section */}
      <div className="container mx-auto px-4 mt-6">
        <div className="w-full relative h-[350px] md:h-[500px] rounded-2xl overflow-hidden group shadow-2xl">
          {slides.map((slide, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              animate={{ opacity: index === currentSlide ? 1 : 0 }}
              transition={{ duration: 1 }}
              className={`absolute inset-0 ${index === currentSlide ? 'z-10' : 'z-0'}`}
            >
              <img 
                src={slide.image} 
                alt={slide.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent flex items-center px-8 md:px-20">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: index === currentSlide ? 1 : 0, y: index === currentSlide ? 0 : 20 }}
                  transition={{ delay: 0.5, duration: 0.5 }}
                  className="max-w-2xl text-white"
                >
                  <h2 className="text-4xl md:text-7xl font-black mb-6 leading-tight drop-shadow-lg">
                    {slide.title}
                  </h2>
                  <p className="text-xl md:text-2xl mb-8 font-medium text-gray-200 drop-shadow-md">
                    {slide.subtitle}
                  </p>
                  <Link 
                    to="/about"
                    className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-xl font-black transition-all transform hover:scale-105 shadow-xl hover:shadow-blue-500/50"
                  >
                    আরো জানুন
                  </Link>
                </motion.div>
              </div>
            </motion.div>
          ))}
          
          {/* Slider Controls */}
          <button 
            onClick={prevSlide}
            className="absolute left-6 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 backdrop-blur-md p-4 rounded-full text-white z-20 opacity-0 group-hover:opacity-100 transition-all transform hover:scale-110"
          >
            <ChevronLeft size={32} />
          </button>
          <button 
            onClick={nextSlide}
            className="absolute right-6 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 backdrop-blur-md p-4 rounded-full text-white z-20 opacity-0 group-hover:opacity-100 transition-all transform hover:scale-110"
          >
            <ChevronRight size={32} />
          </button>
          
          {/* Slider Dots */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-3 z-20">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentSlide(i)}
                className={`transition-all duration-300 rounded-full ${
                  i === currentSlide 
                    ? 'w-10 h-3 bg-blue-600 shadow-lg shadow-blue-500/50' 
                    : 'w-3 h-3 bg-white/50 hover:bg-white/80'
                }`}
              ></button>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Link Cards */}
      <div className="container mx-auto px-4 mt-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <QuickLink to="/admission" icon={<FileText className="text-white" />} label="ভর্তি আবেদন" sub="অনলাইনে ভর্তি করুন" color="bg-blue-600" />
          <QuickLink to="/results" icon={<Search className="text-white" />} label="ফলাফল দেখুন" sub="পরীক্ষার ফলাফল দেখুন" color="bg-green-600" />
          <QuickLink to="/notices" icon={<Bell className="text-white" />} label="নোটিশ বোর্ড" sub="সর্বশেষ নোটিশ দেখুন" color="bg-orange-500" />
          <QuickLink to="/daily-update" icon={<BookOpen className="text-white" />} label="Daily Class Update" sub="আজকের পড়া দেখুন" color="bg-purple-600" />
          <QuickLink to="/contact" icon={<PhoneCall className="text-white" />} label="যোগাযোগ করুন" sub="আমাদের সাথে যোগাযোগ" color="bg-red-600" />
        </div>
      </div>

      <div className="container mx-auto px-4 mt-12">
        {/* Head Teacher's Message - Expanded */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
           <div className="bg-[#002147] text-white py-4 px-8 text-xl font-black">প্রধান শিক্ষকের বাণী</div>
           <div className="p-8 md:p-12">
              <div className="flex flex-col md:flex-row gap-12 items-center md:items-start">
                 <div className="shrink-0">
                    <img 
                      src={getDirectImageUrl(settings?.headTeacherImage) || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&h=600&fit=crop"} 
                      alt="Head Teacher" 
                      className="w-64 h-64 md:w-80 md:h-80 object-cover rounded-2xl shadow-2xl border-8 border-gray-50"
                    />
                    <div className="text-center mt-6">
                       <h4 className="text-2xl font-black text-[#002147]">{settings?.headTeacherName || 'শাহিনা পারভিন'}</h4>
                       <p className="text-base font-bold text-red-600 uppercase tracking-widest mt-1">প্রধান শিক্ষক</p>
                    </div>
                 </div>
                 <div className="flex-1">
                    <div className="relative">
                      <span className="text-6xl text-blue-100 absolute -top-8 -left-4 font-serif">"</span>
                      <p className="text-gray-600 text-lg md:text-xl leading-relaxed text-justify relative z-10 font-medium italic">
                        {settings?.headTeacherMessage || 'প্রিয় শিক্ষার্থী, অভিভাবক ও শুভানুধ্যায়ী, খাগুটিয়া প্রাথমিক বিদ্যালয়ে আমরা মানসম্মত শিক্ষা প্রদানের পাশাপাশি শিক্ষার্থীদের নৈতিক ও মানসিক বিকাশে কাজ করে যাচ্ছি। আপনাদের সহযোগিতা ও ভালোবাসাই আমাদের পথচলার প্রেরণা। আমরা বিশ্বাস করি প্রতিটি শিশুই অমিত সম্ভাবনার অধিকারী। আমাদের লক্ষ্য হলো সেই সম্ভাবনাকে জাগিয়ে তোলা এবং তাদের একবিংশ শতাব্দীর চ্যালেঞ্জ মোকাবেলায় যোগ্য নাগরিক হিসেবে গড়ে তোলা। তথ্য-প্রযুক্তির এই যুগে আমরা আমাদের শিক্ষার্থীদের ডিজিটাল শিক্ষায় শিক্ষিত করার জন্য নিরলস কাজ করে যাচ্ছি। আমাদের অভিজ্ঞ শিক্ষক মন্ডলী অত্যন্ত আন্তরিকতার সাথে পাঠদান করে থাকেন। আপনাদের সন্তানের উজ্জ্বল ভবিষ্যৎ কামনায় আমরা সবসময় আপনাদের পাশে আছি। সরাসরি বিদ্যালয়ের সাথে যোগাযোগ করার জন্য অনুরোধ করা হলো।'}
                      </p>
                    </div>
                    <div className="mt-12 flex flex-wrap gap-4">
                      <Link to="/about" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-black transition-all flex items-center gap-2 shadow-lg shadow-blue-200">
                        বিস্তারিত ইতিহাস <ArrowRight size={20} />
                      </Link>
                      <Link to="/contact" className="bg-red-50 text-red-600 px-8 py-4 rounded-xl font-black border border-red-100 hover:bg-red-600 hover:text-white transition-all shadow-sm">
                        সরাসরি যোগাযোগ করুন
                      </Link>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>


      {/* Gallery Section */}
      <div className="container mx-auto px-4 mt-12 bg-white rounded-lg shadow-md p-6 border border-gray-100">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-[#002147] border-l-4 border-red-600 pl-4">গ্যালারি</h3>
          <Link to="/gallery" className="text-blue-600 font-bold hover:underline">সব দেখুন ({'->'})</Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
           {gallery.length > 0 ? (
             gallery.map((item, i) => (
               <Link to="/gallery" key={item.id || i} className="aspect-video rounded-lg overflow-hidden group cursor-pointer relative shadow-sm">
                 <img 
                   src={getDirectImageUrl(item.imageUrl)} 
                   alt={item.caption || "Gallery"} 
                   className="w-full h-full object-cover transition-transform group-hover:scale-110"
                 />
                 <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors"></div>
               </Link>
             ))
           ) : (
             [1, 2, 3, 4].map(i => (
               <div key={i} className="aspect-video rounded-lg overflow-hidden group cursor-pointer relative shadow-sm">
                 <img 
                   src={`https://images.unsplash.com/photo-1546410531-bb4caa6b424d?q=80&w=800&auto=format&fit=crop&sig=${i}`} 
                   alt="Gallery" 
                   className="w-full h-full object-cover transition-transform group-hover:scale-110"
                 />
                 <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors"></div>
               </div>
             ))
           )}
        </div>
      </div>

    </div>
  );
};

const QuickLink = ({ to, icon, label, sub, color }: { to: string, icon: any, label: string, sub: string, color: string }) => (
  <Link to={to} className="flex items-center gap-4 p-4 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow border border-gray-100">
     <div className={`p-3 rounded-full ${color}`}>
       {icon}
     </div>
     <div>
       <div className="font-bold text-gray-800 leading-none mb-1">{label}</div>
       <div className="text-[10px] text-gray-500 font-semibold">{sub}</div>
     </div>
  </Link>
);

const NoticeItem = ({ date, month, title }: { date: string, month: string, title: string }) => (
  <div className="flex gap-4 items-center group cursor-pointer">
    <div className="bg-blue-50 text-[#002147] p-2 rounded w-16 text-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
      <div className="text-lg font-black leading-none">{date}</div>
      <div className="text-[10px] font-bold">{month}</div>
    </div>
    <div className="flex-1 font-bold text-sm text-gray-700 leading-none group-hover:text-blue-600 transition-colors">
      {title}
    </div>
  </div>
);

const ClassUpdateItem = ({ icon, className, subject }: { icon: any, className: string, subject: string }) => (
  <div className="flex gap-4 items-center p-2 hover:bg-gray-50 rounded transition-colors cursor-pointer">
    <div className="p-2 bg-gray-100 rounded-full">{icon}</div>
    <div>
      <div className="font-bold text-sm text-gray-800">{className}</div>
      <div className="text-xs text-gray-500">{subject}</div>
    </div>
  </div>
);

const StatCard = ({ icon, count, label }: { icon: any, count: string, label: string }) => (
  <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 flex flex-col items-center text-center">
    <div className="text-blue-600 mb-4">{icon}</div>
    <div className="text-3xl font-black text-[#002147] mb-1">{count}</div>
    <div className="text-sm font-bold text-gray-500">{label}</div>
  </div>
);

export default Home;
