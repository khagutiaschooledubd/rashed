import React, { useState, useEffect } from 'react';
import { Phone, Mail, Bell } from 'lucide-react';
import { getSettings } from '../../services/api';
import { SiteSettings } from '../../types';

const TopBar = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      const data = await getSettings();
      setSettings(data);
    };
    fetchSettings();
  }, []);

  return (
    <div className="bg-[#002147] text-white py-2 px-4 text-sm hidden md:block">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <Phone size={14} className="text-yellow-400" />
            <span>যোগাযোগঃ {settings?.contactPhone || '01787 593234'}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Mail size={14} className="text-yellow-400" />
            <span>Email: {settings?.contactEmail || 'info@khagutiaschool.edu.bd@gmail.com'}</span>
          </div>
        </div>
        
        {settings?.scrollingNotice && (
          <div className="flex-1 ml-10 overflow-hidden relative h-6">
            <div className="absolute whitespace-nowrap animate-marquee flex items-center space-x-2">
              <Bell size={14} className="text-yellow-400" />
              <span className="font-bold">নোটিশঃ {settings.scrollingNotice}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TopBar;
