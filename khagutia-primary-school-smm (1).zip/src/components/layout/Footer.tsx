import React from 'react';
import { Mail, Phone, MapPin, Facebook, Youtube, Globe, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#001530] text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & About */}
          <div className="col-span-1 lg:col-span-1">
             <h3 className="text-white text-xl font-bold mb-6 border-l-4 border-yellow-400 pl-3">
               খাগুটিয়া প্রাথমিক বিদ্যালয়
             </h3>
             <p className="text-sm leading-relaxed mb-6">
               আমাদের লক্ষ্য হলো একবিংশ শতাব্দীর চ্যালেঞ্জ মোকাবেলায় শিক্ষার্থীদের তথ্য-প্রযুক্তি নির্ভর মানসম্মত ও নৈতিক শিক্ষা প্রদান করে দেশের শ্রেষ্ঠ নাগরিক হিসেবে গড়ে তোলা।
             </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white text-lg font-bold mb-6 border-l-4 border-yellow-400 pl-3">জরুরি লিঙ্ক</h3>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">অনলাইন ভর্তি</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">ফলাফল আর্কাইভ</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">শিক্ষক পরিচিতি</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">ছুটির তালিকা</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">ডাউনলোড কর্নার</a></li>
            </ul>
          </div>

          {/* Other Links */}
          <div>
            <h3 className="text-white text-lg font-bold mb-6 border-l-4 border-yellow-400 pl-3">অন্যান্য</h3>
            <ul className="space-y-3 text-sm">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">প্রাথমিক শিক্ষা অধিদপ্তর</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">শিক্ষা মন্ত্রণালয়</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">শিক্ষক বাতায়ন</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">জাতীয় তথ্য বাতায়ন</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white text-lg font-bold mb-6 border-l-4 border-yellow-400 pl-3">যোগাযোগের তথ্য</h3>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-yellow-400 shrink-0" />
                <span>খাগুটিয়া, ঝালকাঠি, বরিশাল, বাংলাদেশ</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-yellow-400 shrink-0" />
                <span>01787 593234</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-yellow-400 shrink-0" />
                <span>info@khagutiaschool.edu.bd</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-blue-900 py-10 bg-[#000F24]">
        <div className="container mx-auto px-4 text-center md:text-left">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-base md:text-lg text-gray-400 font-bold">
            <p>© ২০২৩ খাগুটিয়া প্রাথমিক বিদ্যালয় | সর্বস্বত্ব সংরক্ষিত</p>
            <p className="font-black text-white/90">
              website developed by Rashid Ahmed for contact 01710578620
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
