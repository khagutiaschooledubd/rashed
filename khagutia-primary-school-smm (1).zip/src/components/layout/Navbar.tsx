import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Menu, X, LogIn } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  const menuItems = [
    { name: 'হোম', path: '/', icon: <Home size={18} /> },
    { name: 'আমাদের সম্পর্কে', path: '/about' },
    { name: 'ভর্তি', path: '/admission' },
    { name: 'নোটিশ বোর্ড', path: '/notices' },
    { name: 'পরীক্ষার রুটিন', path: '/routines' },
    { name: 'ফলাফল', path: '/results' },
    { name: 'গ্যালারি', path: '/gallery' },
    { name: 'Daily Class Update', path: '/daily-update' },
    { name: 'যোগাযোগ', path: '/contact' },
  ];

  return (
    <nav className="bg-[#002147] text-white sticky top-0 z-50">
      <div className="container mx-auto">
        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center">
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `px-5 py-4 text-sm font-bold uppercase transition-colors flex items-center gap-2 border-r border-blue-900 group hover:bg-[#F2A900] hover:text-[#002147] ${
                  isActive ? 'bg-[#F2A900] text-[#002147]' : ''
                }`
              }
            >
              {item.icon}
              {item.name}
            </NavLink>
          ))}
          <div className="ml-auto flex">
            <NavLink 
              to="/login"
              className="px-6 py-4 text-sm font-bold bg-red-600 hover:bg-red-700 flex items-center gap-2 transition-colors"
            >
              <LogIn size={18} />
              লগইন
            </NavLink>
          </div>
        </div>

        {/* Mobile Menu Toggle */}
        <div className="lg:hidden flex justify-between items-center px-4 py-3">
          <span className="font-bold">মেনু</span>
          <button onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="lg:hidden flex flex-col bg-[#001530]">
            {menuItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className="px-4 py-3 text-sm font-bold border-b border-blue-900 hover:bg-[#F2A900] hover:text-[#002147]"
              >
                {item.name}
              </NavLink>
            ))}
            <NavLink
              to="/login"
              className="px-4 py-3 text-sm font-bold bg-red-600"
              onClick={() => setIsOpen(false)}
            >
              লগইন
            </NavLink>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
