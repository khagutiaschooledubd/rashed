import React, { useState, useEffect } from 'react';
import { getSettings } from '../../services/api';
import { SiteSettings } from '../../types';
import { getDirectImageUrl } from '../../lib/imageUtils';

const Header = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      const data = await getSettings();
      setSettings(data);
    };
    fetchSettings();
  }, []);

  const logoSrc = settings?.logoUrl ? getDirectImageUrl(settings.logoUrl) : "https://khagutia-pri-school.vercel.app/logo.png";
  const govLogoDefault = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Government_Seal_of_Bangladesh.svg/1200px-Government_Seal_of_Bangladesh.svg.png";
  const govLogoSrc = settings?.govLogoUrl ? getDirectImageUrl(settings.govLogoUrl) : govLogoDefault;

  return (
    <div className="bg-white py-1">
      <div className="border-t-[3px] border-b-[3px] border-[#002147] py-6 md:py-8">
        <div className="px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 md:gap-10 max-w-7xl mx-auto">
            {/* Left Logo */}
            <div className="w-20 h-20 md:w-28 md:h-28 lg:w-36 lg:h-36 shrink-0 flex items-center justify-center">
              <img 
                src={logoSrc} 
                alt="School Logo" 
                className="max-w-full max-h-full object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Govt_Primary_School_Logo.svg/1024px-Govt_Primary_School_Logo.svg.png';
                }}
              />
            </div>

            {/* Center Content */}
            <div className="flex-1 text-center min-w-0">
              <h1 className="text-3xl md:text-4xl lg:text-6xl font-extrabold text-[#002147] tracking-tighter font-display mb-1 whitespace-nowrap">
                খাগুটিয়া প্রাথমিক বিদ্যালয়
              </h1>
              <h2 className="text-lg md:text-2xl lg:text-3xl font-bold text-red-600 tracking-tighter uppercase whitespace-nowrap">
                Khagutia Primary School
              </h2>
            </div>

            {/* Right Gov Logo */}
            <div className="w-24 h-24 md:w-32 md:h-32 lg:w-44 lg:h-44 shrink-0 flex items-center justify-center">
              <img 
                src={govLogoSrc} 
                alt="Gov Logo" 
                className="max-w-full max-h-full object-contain"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
