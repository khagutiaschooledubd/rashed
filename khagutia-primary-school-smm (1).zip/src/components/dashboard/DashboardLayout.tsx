import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { 
  BarChart3, 
  Users, 
  UserSquare2, 
  BookCopy, 
  Bell, 
  Image as ImageIcon, 
  Settings, 
  LogOut,
  LayoutDashboard,
  Home,
  User
} from 'lucide-react';
import { getDirectImageUrl } from '../../lib/imageUtils';

interface DashboardLayoutProps {
  children: React.ReactNode;
  role: 'admin' | 'teacher' | 'student';
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children, role }) => {
  const { profile, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const navItems = {
    admin: [
      { name: 'Dashboard', path: '/admin', icon: <LayoutDashboard size={20} /> },
      { name: 'Students', path: '/admin/students', icon: <Users size={20} /> },
      { name: 'Teachers', path: '/admin/teachers', icon: <UserSquare2 size={20} /> },
      { name: 'Notices', path: '/admin/notices', icon: <Bell size={20} /> },
      { name: 'Homework', path: '/admin/homework', icon: <BookCopy size={20} /> },
      { name: 'Gallery', path: '/admin/gallery', icon: <ImageIcon size={20} /> },
      { name: 'Settings', path: '/admin/settings', icon: <Settings size={20} /> },
    ],
    teacher: [
      { name: 'Dashboard', path: '/teacher', icon: <LayoutDashboard size={20} /> },
      { name: 'My Classes', path: '/teacher/classes', icon: <Users size={20} /> },
      { name: 'Daily Updates', path: '/teacher/homework', icon: <BookCopy size={20} /> },
      { name: 'Notices', path: '/teacher/notices', icon: <Bell size={20} /> },
    ],
    student: [
      { name: 'Dashboard', path: '/student', icon: <LayoutDashboard size={20} /> },
      { name: 'Daily Updates', path: '/student/updates', icon: <BookCopy size={20} /> },
      { name: 'My Results', path: '/student/results', icon: <BarChart3 size={20} /> },
      { name: 'Notice Board', path: '/student/notices', icon: <Bell size={20} /> },
    ]
  };

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-[#002147] text-white flex flex-col shrink-0">
        <div className="p-6 border-b border-blue-900">
          <h2 className="text-xl font-black tracking-tight flex items-center gap-2">
            <span className="bg-white text-[#002147] px-1 rounded">KPS</span>
            PORTAL
          </h2>
          <p className="text-[10px] text-gray-400 font-bold uppercase mt-1 tracking-widest">{role} ACCESS</p>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {navItems[role].map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors font-medium text-sm"
            >
              <span className="text-blue-400">{item.icon}</span>
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-blue-900">
           <Link to="/" className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/10 transition-colors text-sm mb-2">
             <Home size={20} />
             Back to Home
           </Link>
           <button 
             onClick={handleLogout}
             className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-red-600/20 text-red-400 transition-colors text-sm"
           >
             <LogOut size={20} />
             Logout
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Topbar */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0">
          <h1 className="text-xl font-bold text-gray-800">
            {role.charAt(0).toUpperCase() + role.slice(1)} Portal
          </h1>
          <div className="flex items-center gap-4">
             <div className="text-right hidden sm:block">
               <p className="text-sm font-bold text-gray-800">{profile?.name || 'User'}</p>
               <p className="text-[10px] text-gray-500 font-bold uppercase">{profile?.email}</p>
             </div>
             <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold border border-blue-200 overflow-hidden shadow-inner">
               {profile?.photoURL ? (
                 <img 
                   src={getDirectImageUrl(profile.photoURL)} 
                   alt={profile.name} 
                   className="w-full h-full object-cover"
                   onError={(e) => {
                     e.currentTarget.style.display = 'none';
                     e.currentTarget.parentElement!.innerHTML = profile?.name?.charAt(0) || 'U';
                   }}
                 />
               ) : (
                 profile?.name?.charAt(0) || <User size={20} />
               )}
             </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default DashboardLayout;
