import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import TopBar from './components/layout/TopBar';
import Header from './components/layout/Header';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Home from './components/Home';
import NoticeBoard from './pages/NoticeBoard';
import Gallery from './pages/Gallery';
import Results from './pages/Results';
import About from './pages/About';
import Contact from './pages/Contact';
import DailyClassUpdate from './pages/DailyClassUpdate';
import Routines from './pages/Routines';
import LoginSelector from './pages/LoginSelector';
import Login from './pages/Login';
import AdminOverview from './pages/admin/AdminOverview';
import ManageTeachers from './pages/admin/ManageTeachers';
import ManageStudents from './pages/admin/ManageStudents';
import ManageNotices from './pages/admin/ManageNotices';
import ManageSettings from './pages/admin/ManageSettings';
import ManageHeadTeacher from './pages/admin/ManageHeadTeacher';
import ManageGallery from './pages/admin/ManageGallery';
import ManageResults from './pages/admin/ManageResults';
import ManageHomework from './pages/teacher/ManageHomework';
import TeacherOverview from './pages/teacher/TeacherOverview';
import ManageRoutines from './pages/teacher/ManageRoutines';
import TeacherManageResults from './pages/teacher/ManageResults';
import StudentOverview from './pages/student/StudentOverview';
import StudentResults from './pages/student/Results';
import StudentNoticeBoard from './pages/student/NoticeBoard';
import DashboardLayout from './components/dashboard/DashboardLayout';

// Placeholder for protected routes
const ProtectedRoute = ({ children, role }: { children: React.ReactNode, role: string }) => {
  const { profile, loading } = useAuth();
  
  if (loading) return (
    <div className="h-screen flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );
  
  if (!profile) return <Navigate to="/login" />;
  if (profile.role !== role) return <Navigate to="/" />;
  
  return <>{children}</>;
};

const PagePlaceholder = ({ title }: { title: string }) => (
  <div className="container mx-auto px-4 py-20 text-center">
    <h2 className="text-3xl font-black text-[#002147] mb-4">{title}</h2>
    <p className="text-gray-500">এই পেজটি কাজ চলছে। শীঘ্রই যুক্ত করা হবে।</p>
  </div>
);

const PublicLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen flex flex-col">
    <TopBar />
    <Header />
    <Navbar />
    <main className="flex-1">
      {children}
    </main>
    <Footer />
  </div>
);

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<PublicLayout><Home /></PublicLayout>} />
          <Route path="/about" element={<PublicLayout><About /></PublicLayout>} />
          <Route path="/admission" element={<PublicLayout><PagePlaceholder title="ভর্তি তথ্য" /></PublicLayout>} />
          <Route path="/notices" element={<PublicLayout><NoticeBoard /></PublicLayout>} />
          <Route path="/results" element={<PublicLayout><Results /></PublicLayout>} />
          <Route path="/routines" element={<PublicLayout><Routines /></PublicLayout>} />
          <Route path="/gallery" element={<PublicLayout><Gallery /></PublicLayout>} />
          <Route path="/daily-update" element={<PublicLayout><DailyClassUpdate /></PublicLayout>} />
          <Route path="/contact" element={<PublicLayout><Contact /></PublicLayout>} />
          <Route path="/login" element={<PublicLayout><LoginSelector /></PublicLayout>} />
          <Route path="/auth/login" element={<PublicLayout><Login /></PublicLayout>} />

          {/* Admin Routes */}
          <Route path="/admin/*" element={
            <ProtectedRoute role="admin">
              <DashboardLayout role="admin">
                <Routes>
                  <Route index element={<AdminOverview />} />
                  <Route path="students" element={<ManageStudents />} />
                  <Route path="teachers" element={<ManageTeachers />} />
                  <Route path="notices" element={<ManageNotices />} />
                  <Route path="gallery" element={<ManageGallery />} />
                  <Route path="head-teacher" element={<ManageHeadTeacher />} />
                  <Route path="results" element={<ManageResults />} />
                  <Route path="settings" element={<ManageSettings />} />
                  <Route path="*" element={<Navigate to="/admin" />} />
                </Routes>
              </DashboardLayout>
            </ProtectedRoute>
          } />

          {/* Teacher Routes */}
          <Route path="/teacher/*" element={
            <ProtectedRoute role="teacher">
              <DashboardLayout role="teacher">
                <Routes>
                  <Route index element={<TeacherOverview />} />
                  <Route path="homework" element={<ManageHomework />} />
                  <Route path="routines" element={<ManageRoutines />} />
                  <Route path="results" element={<TeacherManageResults />} />
                  <Route path="*" element={<Navigate to="/teacher" />} />
                </Routes>
              </DashboardLayout>
            </ProtectedRoute>
          } />

          {/* Student Routes */}
          <Route path="/student/*" element={
            <ProtectedRoute role="student">
              <DashboardLayout role="student">
                <Routes>
                  <Route index element={<StudentOverview />} />
                  <Route path="results" element={<StudentResults />} />
                  <Route path="notices" element={<StudentNoticeBoard />} />
                  <Route path="*" element={<Navigate to="/student" />} />
                </Routes>
              </DashboardLayout>
            </ProtectedRoute>
          } />

          {/* Catch all */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
