import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getAll } from '../services/api';
import { GalleryItem } from '../types';
import { getDirectImageUrl } from '../lib/imageUtils';
import { Camera, X, Maximize2 } from 'lucide-react';

const Gallery = () => {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  useEffect(() => {
    const fetchGallery = async () => {
      try {
        const data = await getAll<GalleryItem>('gallery');
        setItems(data.sort((a, b) => {
          const timeA = a.createdAt?.seconds || (a.createdAt instanceof Date ? a.createdAt.getTime() / 1000 : 0);
          const timeB = b.createdAt?.seconds || (b.createdAt instanceof Date ? b.createdAt.getTime() / 1000 : 0);
          return timeB - timeA;
        }));
      } catch (error) {
        console.error('Error fetching gallery:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchGallery();
  }, []);

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Hero Section */}
      <div className="bg-[#002147] text-white py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400 rounded-full translate-x-1/2 translate-y-1/2 blur-3xl"></div>
        </div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center mb-6"
          >
            <div className="p-4 bg-white/10 backdrop-blur-md rounded-3xl border border-white/20">
              <Camera size={40} className="text-blue-300" />
            </div>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-black mb-4 tracking-tight"
          >
            ফটোগ্যালারি
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-blue-200 text-lg md:text-xl font-medium max-w-2xl mx-auto leading-relaxed"
          >
            খাগুটিয়া সরকারি প্রাথমিক বিদ্যালয়ের বিভিন্ন সময়ের স্মৃতি ও আয়োজনের কিছু খণ্ডচিত্র।
          </motion.p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-10 relative z-20">
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-80 bg-white rounded-[2rem] shadow-sm animate-pulse" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="bg-white rounded-[2.5rem] p-20 text-center shadow-xl border border-gray-100">
            <Camera size={64} className="mx-auto text-gray-200 mb-6" />
            <h3 className="text-2xl font-bold text-gray-800 mb-2">গ্যালারিতে কোনো ছবি নেই</h3>
            <p className="text-gray-500">খুব শীঘ্রই বিদ্যালয়ের কার্যক্রমের ছবি এখানে যুক্ত করা হবে।</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {items.map((item, i) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="group relative bg-white rounded-[2.5rem] overflow-hidden shadow-md hover:shadow-2xl transition-all border border-gray-100 cursor-pointer"
                onClick={() => setSelectedImage(item)}
              >
                <div className="aspect-square overflow-hidden relative">
                  <img 
                    src={getDirectImageUrl(item.imageUrl)} 
                    alt={item.caption}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="p-4 bg-white/20 backdrop-blur-md rounded-full border border-white/30 transform scale-50 group-hover:scale-100 transition-transform">
                      <Maximize2 size={24} className="text-white" />
                    </div>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <p className="text-gray-800 font-bold text-lg leading-tight line-clamp-2">
                    {item.caption || 'স্কুল অ্যাক্টিভিটি'}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedImage(null)}
              className="absolute inset-0 bg-black/95 backdrop-blur-xl"
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative max-w-5xl w-full max-h-full flex flex-col items-center"
            >
              <button 
                onClick={() => setSelectedImage(null)}
                className="absolute -top-14 right-0 md:-right-14 p-3 bg-white text-black rounded-full hover:bg-gray-100 transition-colors z-10"
              >
                <X size={28} />
              </button>

              <div className="w-full h-full flex flex-col bg-transparent rounded-[2rem] overflow-hidden">
                <div className="flex-1 overflow-hidden flex items-center justify-center">
                  <img 
                    src={getDirectImageUrl(selectedImage.imageUrl)} 
                    alt={selectedImage.caption}
                    className="max-w-full max-h-[70vh] object-contain rounded-2xl shadow-2xl"
                  />
                </div>
                <div className="w-full mt-8 text-center px-4">
                  <h3 className="text-white text-2xl md:text-3xl font-black mb-2 tracking-tight">
                    {selectedImage.caption || 'গ্যালারি ফটো'}
                  </h3>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Gallery;
