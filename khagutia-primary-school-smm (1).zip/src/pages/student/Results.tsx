import React, { useState, useEffect } from 'react';
import { Search, FileText, User, BookOpen, GraduationCap, Award, Calendar, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { ExamResult, StudentProfile } from '../../types';
import { useAuth } from '../../context/AuthContext';

const Results = () => {
  const { profile } = useAuth();
  const [studentData, setStudentData] = useState<StudentProfile | null>(profile?.role === 'student' ? (profile as any) : null);
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [exams, setExams] = useState<string[]>([]);
  const [selectedExam, setSelectedExam] = useState<string>('');

  useEffect(() => {
    const fetchResults = async () => {
      setLoading(true);
      try {
        let currentStudentProfile = profile?.role === 'student' ? (profile as any) : null;

        // Fetch profile if missing essential items
        if (profile?.role === 'student' && (!profile.rollNo || !profile.className)) {
          const studentId = (profile as any).studentId;
          const { getDoc, doc } = await import('firebase/firestore');
          const studentDoc = await getDoc(doc(db, 'students', studentId));
          if (studentDoc.exists()) {
            const data = studentDoc.data() as StudentProfile;
            currentStudentProfile = { ...data, id: studentDoc.id };
            setStudentData(currentStudentProfile);
          }
        } else {
          setStudentData(currentStudentProfile);
        }

        if (!currentStudentProfile?.rollNo) {
          setLoading(false);
          return;
        }

        // Try matching rollNo as string and number
        const roll = currentStudentProfile.rollNo;
        const q = query(
          collection(db, 'results'), 
          where('rollNo', 'in', [String(roll), Number(roll)])
        );
        const querySnapshot = await getDocs(q);
        let data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ExamResult));
        
        // Filter by class in memory to simplify queries
        data = data.filter(r => r.className === currentStudentProfile.className);
        
        // Group by exam name
        const uniqueExams = Array.from(new Set(data.map(r => r.examName)));
        setExams(uniqueExams);
        if (uniqueExams.length > 0) {
          setSelectedExam(uniqueExams[0]);
        }
        setResults(data);
      } catch (error) {
        console.error('Error fetching student results:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [profile]);

  const filteredResults = results.filter(r => r.examName === selectedExam);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-indigo-50 text-indigo-600 rounded-3xl shadow-inner">
              <Award size={32} />
            </div>
            <div>
              <h2 className="text-3xl font-black text-gray-900">ফলাফল (Results)</h2>
              <p className="text-gray-500 font-bold uppercase tracking-widest text-xs mt-1">ব্যক্তিগত ফলাফল বিশ্লেষণ</p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-sm font-bold text-gray-500 bg-gray-50 px-6 py-3 rounded-2xl border border-gray-100">
            <div className="text-center">
              <p className="text-[10px] text-gray-400">CLASS</p>
              <p className="text-blue-600">{studentData?.className}</p>
            </div>
            <div className="w-px h-8 bg-gray-200"></div>
            <div className="text-center">
              <p className="text-[10px] text-gray-400">ROLL</p>
              <p className="text-blue-600">{studentData?.rollNo}</p>
            </div>
          </div>
        </div>

        {exams.length > 0 ? (
          <div className="space-y-8">
            {/* Exam Selector Tags */}
            <div className="flex flex-wrap gap-3">
              {exams.map(exam => (
                <button
                  key={exam}
                  onClick={() => setSelectedExam(exam)}
                  className={`px-6 py-3 rounded-2xl font-bold transition-all ${
                    selectedExam === exam 
                      ? 'bg-[#002147] text-white shadow-lg' 
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  {exam}
                </button>
              ))}
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-1 gap-4">
              {filteredResults.map((res, i) => (
                <motion.div 
                  key={res.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center justify-between p-5 bg-gray-50 rounded-[2rem] border border-gray-200 hover:border-blue-300 transition-all group"
                >
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-white rounded-2xl border border-gray-100 flex items-center justify-center text-gray-400 group-hover:text-blue-600 shadow-sm transition-colors">
                      <BookOpen size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-gray-800">{res.subject}</h3>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-tighter">বিষয় ভিত্তিক ফলাফল</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-[10px] font-black text-gray-400 uppercase">প্রাপ্ত নম্বর</p>
                      <p className="text-2xl font-black text-gray-900 leading-none">{res.marks}</p>
                    </div>
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-black shadow-sm ring-1 ${
                      res.grade === 'A+' ? 'bg-green-50 text-green-600 ring-green-100' : 
                      res.grade === 'F' ? 'bg-red-50 text-red-600 ring-red-100' : 
                      'bg-white text-blue-600 ring-blue-100'
                    }`}>
                      {res.grade}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Summary Card */}
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2.5rem] text-white shadow-xl shadow-blue-200 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 -translate-y-1/2 translate-x-1/2 rounded-full blur-3xl"></div>
               <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
                  <div>
                    <h4 className="text-blue-200 font-bold uppercase tracking-widest text-xs mb-2">{selectedExam} ওভারভিউ</h4>
                    <p className="text-2xl font-black">অভিনন্দন! আপনি চমৎকার ফলাফল করেছেন।</p>
                  </div>
                  <div className="flex gap-4">
                     <div className="bg-white/10 backdrop-blur-md p-4 rounded-3xl border border-white/20">
                        <p className="text-[10px] font-bold text-blue-200 uppercase mb-1 text-center">গড় গ্রেড</p>
                        <p className="text-3xl font-black text-center">A+</p>
                     </div>
                     <div className="bg-white/10 backdrop-blur-md p-4 rounded-3xl border border-white/20">
                        <p className="text-[10px] font-bold text-blue-200 uppercase mb-1 text-center">মেধা স্থান</p>
                        <p className="text-3xl font-black text-center">০৫</p>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-20 bg-gray-50 rounded-[2.5rem] border-2 border-dashed border-gray-200">
            <FileText size={64} className="mx-auto text-gray-200 mb-4" />
            <p className="text-gray-500 font-bold text-lg">আপনার কোনো ফলাফল এখনও আপলোড করা হয়নি।</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Results;
