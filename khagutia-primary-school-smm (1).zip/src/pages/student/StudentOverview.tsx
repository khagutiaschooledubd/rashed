import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  Calendar, 
  Search,
  Bell,
  CheckCircle2,
  Trophy,
  User,
  FileText
} from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../../context/AuthContext';
import { getAll } from '../../services/api';
import { HomeWork, StudentProfile, ExamResult } from '../../types';
import { format } from 'date-fns';
import { getDirectImageUrl } from '../../lib/imageUtils';
import { Link } from 'react-router-dom';
import { collection, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';

const StudentOverview = () => {
  const { profile } = useAuth();
  const [studentData, setStudentData] = useState<StudentProfile | null>(profile?.role === 'student' ? (profile as any) : null);
  const [homeworks, setHomeworks] = useState<HomeWork[]>([]);
  const [latestResult, setLatestResult] = useState<ExamResult | null>(null);
  const [notices, setNotices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        let currentStudentProfile = profile?.role === 'student' ? (profile as any) : null;

        // If session profile is missing essential fields, fetch from DB
        if (profile?.role === 'student' && (!profile.rollNo || !profile.className)) {
          const studentId = (profile as any).studentId;
          const { getDoc, doc } = await import('firebase/firestore');
          const studentDoc = await getDoc(doc(db, 'students', studentId));
          if (studentDoc.exists()) {
            const data = studentDoc.data() as StudentProfile;
            currentStudentProfile = { ...data, id: studentDoc.id };
            setStudentData(currentStudentProfile);
          }
        } else {
          setStudentData(currentStudentProfile);
        }

        const studentClass = currentStudentProfile?.className || 'One';
        
        // Load homework
        const data = await getAll<HomeWork>('homework');
        setHomeworks(data.filter(h => h.className === studentClass).slice(0, 5));

        // Load notices
        const noticesData = await getAll<any>('notices', [orderBy('date', 'desc'), limit(3)]);
        setNotices(noticesData);

        // Load latest result
        if (currentStudentProfile?.rollNo) {
          try {
            // Try matching rollNo as string and number
            const roll = currentStudentProfile.rollNo;
            const q = query(
              collection(db, 'results'), 
              where('rollNo', 'in', [String(roll), Number(roll)])
            );
            const resultRes = await getDocs(q);
            if (!resultRes.empty) {
              const allResults = resultRes.docs
                .map(doc => ({ id: doc.id, ...doc.data() } as ExamResult))
                .filter(r => r.className === studentClass);
                
              if (allResults.length > 0) {
                // Sort by examName or creation date if available
                allResults.sort((a, b) => (b.examName || '').localeCompare(a.examName || ''));
                setLatestResult(allResults[0]);
              }
            }
          } catch (err) {
            console.error("Result fetch error:", err);
          }
        }
      } catch (error) {
        console.error("Error loading dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [profile]);

  return (
    <div className="space-y-8">
      {/* Header Profile Section */}
      <div className="bg-gradient-to-r from-[#002147] to-blue-900 rounded-[2.5rem] p-8 text-white shadow-xl flex flex-col md:flex-row items-center gap-8 border-b-8 border-yellow-400">
         <div className="w-24 h-24 rounded-3xl bg-white/10 flex items-center justify-center text-4xl font-black border border-white/20 overflow-hidden shadow-inner">
            {studentData?.image ? (
              <img 
                src={getDirectImageUrl(studentData.image)} 
                alt={studentData.name} 
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.parentElement!.innerHTML = profile?.name?.charAt(0) || '<svg ...></svg>';
                }}
              />
            ) : (
              profile?.name?.charAt(0) || <User size={40} />
            )}
         </div>
         <div className="flex-1 text-center md:text-left">
            <p className="text-yellow-400 font-bold uppercase tracking-widest text-xs mb-1">স্টুডেন্ট পোর্টাল</p>
            <h2 className="text-3xl font-black mb-2">{profile?.name}</h2>
            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
               <span className="bg-black/20 px-3 py-1 rounded-lg text-sm font-bold border border-white/10 flex items-center gap-2">
                 <GraduationCap size={16} /> শ্রেণিঃ {studentData?.className || 'প্রাথমিক'}
               </span>
               <span className="bg-black/20 px-3 py-1 rounded-lg text-sm font-bold border border-white/10 flex items-center gap-2">
                 <Calendar size={16} /> সেশনঃ ২০২৬
               </span>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Homework List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-2xl font-black text-gray-800 flex items-center gap-3">
              <BookOpen size={24} className="text-purple-600" />
              আজকের পড়া (Daily Homework)
            </h3>
            <button className="text-blue-600 font-bold text-sm hover:underline">সব দেখুন</button>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => <div key={i} className="h-24 bg-white animate-pulse rounded-2xl border border-gray-100"></div>)}
            </div>
          ) : homeworks.length > 0 ? (
            <div className="space-y-4">
              {homeworks.map((hw, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  key={hw.id} 
                  className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-6 group hover:shadow-md transition-all"
                >
                  <div className="w-16 h-16 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 font-black text-sm shrink-0 border border-purple-100">
                    {hw.date ? format(hw.date.toDate(), 'dd MMM') : 'N/A'}
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-black text-purple-600 uppercase mb-1">{hw.subject}</p>
                    <h4 className="text-lg font-black text-gray-800 leading-tight mb-2 group-hover:text-blue-600 transition-colors">{hw.title}</h4>
                    <p className="text-sm text-gray-500 font-medium line-clamp-1">{hw.description}</p>
                  </div>
                  <CheckCircle2 size={24} className="text-gray-200 group-hover:text-green-500 transition-colors" />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="bg-white p-12 rounded-2xl text-center border-2 border-dashed border-gray-100">
              <p className="text-gray-400 font-bold">আজকের কোনো হোমওয়ার্ক আপলোড করা হয়নি।</p>
            </div>
          )}
        </div>

        {/* Sidebar Mini Components */}
        <div className="space-y-8">
            <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-gray-100">
              <h3 className="text-lg font-black text-gray-800 mb-4 flex items-center gap-2">
                <Trophy size={20} className="text-yellow-600" />
                সর্বশেষ ফলাফল (Result)
              </h3>
              {latestResult ? (
                <div className="p-4 bg-yellow-50 rounded-2xl border border-yellow-100 flex items-center justify-between">
                   <div>
                     <p className="text-[10px] font-black text-yellow-700 uppercase truncate max-w-[150px]">{latestResult.examName}</p>
                     <p className="text-lg font-black text-gray-800">Grade: {latestResult.grade}</p>
                     <p className="text-[10px] font-bold text-gray-500">{latestResult.subject}</p>
                   </div>
                   <div className="bg-white p-2 rounded-xl text-yellow-600 font-black text-sm shadow-sm ring-1 ring-yellow-200">
                     {latestResult.marks}%
                   </div>
                </div>
              ) : (
                <div className="p-6 bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-center">
                  <p className="text-xs font-bold text-gray-400">কোনো ফলাফল পাওয়া যায়নি</p>
                </div>
              )}
              <Link 
                to="/student/results" 
                className="w-full mt-4 py-3 bg-[#002147] text-white font-bold text-sm rounded-xl hover:bg-blue-900 transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-50"
              >
                <FileText size={16} />
                পূর্ণাঙ্গ রেজাল্ট দেখুন
              </Link>
            </div>

           <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-gray-100">
             <h3 className="text-lg font-black text-gray-800 mb-4 flex items-center gap-2 text-indigo-600">
               <Bell size={20} />
               স্কুল নোটিশ
             </h3>
             <div className="space-y-4">
               {notices.length > 0 ? (
                 notices.map((notice, i) => (
                   <div key={notice.id || i} className="flex gap-3">
                     <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 shrink-0"></div>
                     <p className="text-sm font-medium text-gray-700 leading-tight line-clamp-2">{notice.title || notice.content}</p>
                   </div>
                 ))
               ) : (
                 <p className="text-xs font-bold text-gray-400 text-center py-4">কোনো নোটিশ পাওয়া যায়নি</p>
               )}
             </div>
             <Link 
               to="/student/notices" 
               className="w-full mt-4 py-3 bg-indigo-50 text-indigo-600 font-bold text-sm rounded-xl hover:bg-indigo-100 transition-colors flex items-center justify-center gap-2"
             >
               সব নোটিশ দেখুন
             </Link>
           </div>
        </div>
      </div>
    </div>
  );
};

export default StudentOverview;
