import React, { useState, useEffect } from 'react';
import { Bell, Calendar, ChevronRight, Search, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAll } from '../../services/api';
import { Notice } from '../../types';
import { orderBy, Timestamp } from 'firebase/firestore';
import { format } from 'date-fns';

const NoticeBoard = () => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    loadNotices();
  }, []);

  const loadNotices = async () => {
    setLoading(true);
    try {
      const data = await getAll<Notice>('notices', [orderBy('date', 'desc')]);
      setNotices(data);
    } catch (error) {
      console.error('Error loading notices:', error);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['All', 'General', 'Examination', 'Admission', 'Holiday'];

  const filteredNotices = notices.filter(notice => {
    const matchesSearch = notice.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         notice.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || notice.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatDate = (date: Timestamp | Date | any) => {
    if (!date) return '';
    const d = date.toDate ? date.toDate() : new Date(date);
    return format(d, 'dd MMMM, yyyy');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      {/* Header */}
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-orange-50 text-orange-600 rounded-3xl shadow-inner">
              <Bell size={32} />
            </div>
            <div>
              <h2 className="text-3xl font-black text-gray-900">নোটিশ বোর্ড (Notice Board)</h2>
              <p className="text-gray-500 font-bold uppercase tracking-widest text-xs mt-1">স্কুলের সকল গুরুত্বপূর্ণ ঘোষণা</p>
            </div>
          </div>

          <div className="relative w-full md:w-64">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
              type="text" 
              placeholder="সার্চ করুন..."
              className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mt-8">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all ${
                selectedCategory === cat 
                  ? 'bg-[#002147] text-white shadow-lg' 
                  : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
              }`}
            >
              {cat === 'All' ? 'সব নোটিশ' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Notice List */}
      <div className="space-y-4">
        {loading ? (
          [1, 2, 3, 4].map(i => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 animate-pulse space-y-3">
              <div className="h-4 w-1/4 bg-gray-100 rounded"></div>
              <div className="h-6 w-3/4 bg-gray-100 rounded"></div>
              <div className="h-20 w-full bg-gray-100 rounded"></div>
            </div>
          ))
        ) : filteredNotices.length > 0 ? (
          filteredNotices.map((notice, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              key={notice.id}
              className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 hover:border-orange-200 transition-all group"
            >
              <div className="flex flex-col md:flex-row gap-6">
                <div className="w-16 h-16 rounded-2xl bg-orange-50 flex flex-col items-center justify-center text-orange-600 shrink-0 border border-orange-100">
                  <Calendar size={24} />
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1 bg-gray-100 text-gray-500 text-[10px] font-black uppercase rounded-lg">
                      {notice.category || 'General'}
                    </span>
                    <span className="text-xs font-bold text-gray-400">
                      {formatDate(notice.date)}
                    </span>
                  </div>
                  <h3 className="text-2xl font-black text-gray-800 group-hover:text-orange-600 transition-colors uppercase tracking-tight">
                    {notice.title}
                  </h3>
                  <div className="text-gray-600 font-medium leading-relaxed whitespace-pre-wrap">
                    {notice.content}
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-20 bg-white rounded-[2.5rem] border border-gray-100">
            <Bell size={64} className="mx-auto text-gray-200 mb-4" />
            <p className="text-gray-500 font-bold text-lg">কোনো নোটিশ পাওয়া যায়নি।</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NoticeBoard;
