import React, { useState, useEffect } from 'react';
import { Calendar, FileText, Download, GraduationCap, Search, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAll } from '../services/api';
import { getDirectImageUrl } from '../lib/imageUtils';

interface Routine {
  id?: string;
  className: string;
  examName: string;
  image: string;
  createdAt?: any;
}

const Routines = () => {
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState('All');

  const classes = ['Nursery', 'Play', 'One', 'Two', 'Three', 'Four', 'Five'];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAll<Routine>('routines');
        setRoutines(data.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
      } catch (error) {
        console.error('Error fetching routines:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const filteredRoutines = routines.filter(r => {
    const matchesSearch = r.examName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === 'All' || r.className === selectedClass;
    return matchesSearch && matchesClass;
  });

  return (
    <div className="bg-gray-50 min-h-screen pb-20 font-bengali">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-[#002147] via-[#003366] to-[#002147] text-white py-24 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <Calendar size={400} className="absolute -bottom-20 -right-20 rotate-12" />
        </div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-block p-4 bg-white/10 backdrop-blur-xl rounded-[2rem] border border-white/20 mb-8"
          >
            <Calendar size={48} className="text-yellow-400" />
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-black mb-6 tracking-tight"
          >
            পরীক্ষার রুটিন
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-blue-100 text-xl font-medium max-w-2xl mx-auto leading-relaxed"
          >
            সকল ক্লাসের সাময়িক ও বার্ষিক পরীক্ষার সর্বশেষ সময়সূচী এখান থেকে দেখুন এবং ডাউনলোড করুন।
          </motion.p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-12 relative z-20">
        {/* Filter Bar */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white p-6 rounded-[2.5rem] shadow-2xl border border-gray-100 mb-12 flex flex-col md:flex-row gap-4"
        >
          <div className="flex-1 relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={24} />
            <input 
              type="text" 
              placeholder="পরীক্ষার নাম দিয়ে খুঁজুন..." 
              className="w-full pl-14 pr-6 py-5 bg-gray-50 border border-gray-200 rounded-3xl outline-none focus:ring-2 focus:ring-blue-500 text-lg font-bold transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select 
            className="px-8 py-5 bg-gray-50 border border-gray-200 rounded-3xl outline-none focus:ring-2 focus:ring-blue-500 font-black text-[#002147]"
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <option value="All">সকল শ্রেণী (All Classes)</option>
            {classes.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </motion.div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-96 bg-white rounded-[2.5rem] animate-pulse border border-gray-100" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatePresence>
              {filteredRoutines.map((routine, i) => (
                <motion.div 
                  key={routine.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden group hover:shadow-2xl transition-all flex flex-col"
                >
                  <div className="h-64 overflow-hidden relative">
                    <img 
                      src={getDirectImageUrl(routine.image)} 
                      alt={routine.examName} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute top-6 left-6">
                      <span className="px-5 py-2 bg-white/95 backdrop-blur text-[#002147] font-black text-sm rounded-2xl shadow-lg border border-white">
                        Class: {routine.className}
                      </span>
                    </div>
                  </div>
                  <div className="p-8 flex-1 flex flex-col">
                    <div className="flex items-start justify-between mb-4">
                       <h3 className="text-2xl font-black text-gray-900 leading-tight flex-1">{routine.examName}</h3>
                    </div>
                    
                    <div className="flex items-center gap-4 py-4 border-t border-gray-50 mt-auto">
                      <div className="flex items-center gap-2 text-gray-400 font-bold text-xs">
                         <Clock size={14} />
                         <span>আপলোডঃ {new Date(routine.createdAt?.seconds * 1000).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <a 
                      href={getDirectImageUrl(routine.image)} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-full py-4 bg-gray-50 hover:bg-[#002147] hover:text-white text-[#002147] font-black rounded-2xl transition-all flex items-center justify-center gap-2 mt-2"
                    >
                      <Download size={20} />
                      রুটিন ডাউনলোড
                    </a>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            {filteredRoutines.length === 0 && (
              <div className="col-span-full py-32 text-center bg-white rounded-[3rem] border border-dashed border-gray-200">
                <FileText size={80} className="mx-auto text-gray-200 mb-6" />
                <h3 className="text-2xl font-black text-gray-800">কোনো রুটিন পাওয়া যায়নি</h3>
                <p className="text-gray-500 font-medium mt-2">অন্য কোনো শ্রেণী বা নাম দিয়ে সার্চ করে দেখুন।</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Guide Section */}
      <div className="max-w-7xl mx-auto px-4 mt-20">
         <div className="bg-indigo-600 rounded-[3rem] p-12 text-white flex flex-col md:flex-row items-center justify-between gap-10 shadow-2xl shadow-indigo-100">
           <div className="max-w-2xl">
              <h2 className="text-3xl font-black mb-4">রুটিন বুঝতে সমস্যা হচ্ছে?</h2>
              <p className="text-indigo-100 text-lg font-medium">যদি কোনো রুটিন ওপেন না হয় বা ইমেজ ঝাপসা থাকে, তবে সরাসরি স্কুলের অফিস কক্ষে যোগাযোগ করার অনুরোধ করা হলো। রুটিন পরিবর্তন হলে এখানে নোটিশ দেওয়া হবে।</p>
           </div>
           <div className="flex gap-4 w-full md:w-auto">
              <div className="flex-1 md:flex-none p-6 bg-white/10 backdrop-blur-md rounded-[2rem] border border-white/20 text-center">
                 <p className="text-2xl font-black text-yellow-400">০১৮৭৮---</p>
                 <p className="text-xs font-bold uppercase tracking-widest text-indigo-200">হেল্পলাইন</p>
              </div>
           </div>
         </div>
      </div>
    </div>
  );
};

export default Routines;
