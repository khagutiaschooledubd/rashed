import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Target, Eye, Award, History } from 'lucide-react';
import { getSettings } from '../services/api';
import { SiteSettings } from '../types';
import { getDirectImageUrl } from '../lib/imageUtils';

const About = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      const s = await getSettings();
      setSettings(s);
    };
    fetchSettings();
  }, []);

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Hero Section */}
      <div className="bg-[#002147] text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white/20 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400/20 rounded-full translate-x-1/2 translate-y-1/2 blur-3xl"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-black mb-6"
          >
            আমাদের সম্পর্কে
          </motion.h1>
          <div className="w-24 h-2 bg-red-600 mx-auto rounded-full"></div>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard 
            icon={<History className="text-blue-600" size={32} />}
            title="গৌরবোজ্জ্বল ইতিহাস"
            description="১৯৮৬ সালে প্রতিষ্ঠিত এই বিদ্যালয়টি দীর্ঘ পথ পাড়ি দিয়ে আজ এই অবস্থানে পৌঁছেছে।"
          />
          <FeatureCard 
            icon={<Target className="text-red-600" size={32} />}
            title="আমাদের লক্ষ্য"
            description="আধুনিক ও নৈতিক শিক্ষার সমন্বয়ে একবিংশ শতাব্দীর চ্যালেঞ্জ মোকাবেলায় যোগ্য নাগরিক গড়ে তোলা।"
          />
          <FeatureCard 
            icon={<Award className="text-yellow-600" size={32} />}
            title="আমাদের অর্জন"
            description="প্রতি বছর অসংখ্য শিক্ষার্থী কৃতিত্বের সাথে প্রাথমিক সমাপনী পরীক্ষায় উত্তীর্ণ হচ্ছে।"
          />
        </div>

        <div className="mt-20 bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-1/2 p-8 md:p-16">
              <h2 className="text-3xl font-black text-[#002147] mb-8 flex items-center gap-4">
                <BookOpen className="text-red-600" /> বিদ্যালয়ের পরিচিতি
              </h2>
              <div className="space-y-6 text-gray-600 leading-relaxed text-lg text-justify font-medium">
                {settings?.aboutHistory ? (
                  <p className="whitespace-pre-line">{settings.aboutHistory}</p>
                ) : (
                  <>
                    <p>
                      খাগুটিয়া প্রাথমিক বিদ্যালয় ঝালকাঠি জেলার একটি অন্যতম বিদ্যাপীঠ। দীর্ঘ কয়েক দশক ধরে এই প্রতিষ্ঠানটি মানসম্মত শিক্ষা প্রসারে কাজ করে যাচ্ছে। আমাদের লক্ষ্য কেবল পুঁথিগত বিদ্যা নয়, বরং শিক্ষার্থীর সুপ্ত প্রতিভা বিকাশ এবং তাকে একজন সুনাগরিক হিসেবে গড়ে তোলা।
                    </p>
                    <p>
                      আমাদের রয়েছে একঝাঁক সুদক্ষ ও অভিজ্ঞ শিক্ষক মন্ডলী যারা অত্যন্ত স্নেহ ও মমতার সাথে পাঠদান নিশ্চিত করেন। আমরা বিশ্বাস করি আজকের শিশুই আগামী দিনের ভবিষ্যৎ, আর সেই ভবিষ্যৎ বিনির্মাণে আমরা সবসময় বদ্ধপরিকর।
                    </p>
                  </>
                )}
              </div>
            </div>
            <div className="lg:w-1/2 bg-gray-100 relative min-h-[400px]">
               <img 
                 src={getDirectImageUrl(settings?.aboutImageUrl) || "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?q=80&w=1200&auto=format&fit=crop"} 
                 alt="School Building" 
                 className="w-full h-full object-cover"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-[#002147]/60 to-transparent flex items-end p-8">
                  <div className="text-white text-right w-full">
                    <p className="text-xl font-bold">{settings?.schoolName || "খাগুটিয়া প্রাথমিক বিদ্যালয়"}</p>
                    <p className="text-sm opacity-80">বিদ্যালয় প্রাঙ্গণ</p>
                  </div>
               </div>
            </div>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="bg-gradient-to-br from-blue-50 to-white p-10 rounded-3xl border border-blue-100">
            <h3 className="text-2xl font-black text-[#002147] mb-6 flex items-center gap-3">
              <Eye className="text-blue-600" /> আমাদের লক্ষ্য (Vision)
            </h3>
            <p className="text-gray-600 leading-relaxed font-medium whitespace-pre-line">
              {settings?.aboutVision || "একটি প্রযুক্তিনির্ভর ও আধুনিক স্মার্ট শিক্ষা ব্যবস্থা গড়ে তোলা যেখানে প্রতিটি শিশু তার সৃজনশীলতা প্রকাশের সর্বোচ্চ সুযোগ পাবে এবং বিশ্বমানের নাগরিক হিসেবে গড়ে উঠবে।"}
            </p>
          </div>
          <div className="bg-gradient-to-br from-red-50 to-white p-10 rounded-3xl border border-red-100">
            <h3 className="text-2xl font-black text-[#002147] mb-6 flex items-center gap-3">
              <Target className="text-red-600" /> আমাদের মিশন (Mission)
            </h3>
            <p className="text-gray-600 leading-relaxed font-medium whitespace-pre-line">
              {settings?.aboutMission || "সবল ও দক্ষ শিক্ষক মন্ডলীর মাধ্যমে নিয়মিত ক্লাস এবং শিক্ষার্থীদের বহুমুখী প্রতিভা বিকাশে খেলাধুলা ও সাংস্কৃতিক কর্মকাণ্ডের মাধ্যমে পরিপূর্ণ বিকাশ নিশ্চিত করা।"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: any, title: string, description: string }) => (
  <motion.div 
    whileHover={{ y: -10 }}
    className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 text-center"
  >
    <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
      {icon}
    </div>
    <h3 className="text-xl font-black text-[#002147] mb-4">{title}</h3>
    <p className="text-gray-500 font-medium leading-relaxed">{description}</p>
  </motion.div>
);

export default About;
