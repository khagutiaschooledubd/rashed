import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit,
  X,
  Check,
  BookOpen
} from 'lucide-react';
import { getAll, createItem, updateItem, deleteItem } from '../../services/api';
import { HomeWork } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { where, orderBy } from 'firebase/firestore';

const ManageHomework = () => {
  const { profile } = useAuth();
  const [updates, setUpdates] = useState<HomeWork[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentUpdate, setCurrentUpdate] = useState<Partial<HomeWork> | null>(null);

  useEffect(() => {
    if (profile) loadUpdates();
  }, [profile]);

  const loadUpdates = async () => {
    setLoading(true);
    // For simplicity in this demo, teachers can see all homework or we can filter by teacherId if we have one
    const data = await getAll<HomeWork>('homework', [orderBy('date', 'desc')]);
    setUpdates(data);
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUpdate || !profile) return;

    const data = {
      ...currentUpdate,
      teacherId: profile.uid,
      teacherName: profile.name,
      date: currentUpdate.date || new Date()
    };

    if (currentUpdate.id) {
      await updateItem('homework', currentUpdate.id, data);
    } else {
      await createItem('homework', data);
    }
    
    setIsModalOpen(false);
    loadUpdates();
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this update?')) {
      await deleteItem('homework', id);
      loadUpdates();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-gray-800">Daily Class Updates</h2>
          <p className="text-gray-500 font-medium">Upload homework and class activities</p>
        </div>
        <button 
          onClick={() => { setCurrentUpdate({}); setIsModalOpen(true); }}
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-transform hover:-translate-y-1"
        >
          <Plus size={20} />
          New Update
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 text-gray-500 text-xs font-black uppercase tracking-wider">
                <th className="px-6 py-4">Class</th>
                <th className="px-6 py-4">Subject</th>
                <th className="px-6 py-4">Title</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                [1, 2, 3].map(i => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={4} className="px-6 py-4"><div className="h-8 bg-gray-100 rounded"></div></td>
                  </tr>
                ))
              ) : updates.map((update) => (
                <tr key={update.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-bold text-purple-600">{update.className}</td>
                  <td className="px-6 py-4 text-sm font-black text-gray-800">{update.subject}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{update.title}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                       <button 
                         onClick={() => { setCurrentUpdate(update); setIsModalOpen(true); }}
                         className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                       >
                         <Edit size={18} />
                       </button>
                       <button 
                         onClick={() => handleDelete(update.id)}
                         className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                       >
                         <Trash2 size={18} />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            ></motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-black text-gray-800">
                    {currentUpdate?.id ? 'Edit Update' : 'New Class Update'}
                  </h3>
                  <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSave} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Class</label>
                      <select 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-purple-500"
                        value={currentUpdate?.className || ''}
                        onChange={(e) => setCurrentUpdate({ ...currentUpdate, className: e.target.value })}
                        required
                      >
                        <option value="">Select Class</option>
                        {['Play', 'Nursery', 'One', 'Two', 'Three', 'Four', 'Five'].map(c => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Subject</label>
                      <input 
                        type="text" 
                        required
                        placeholder="e.g. English"
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-purple-500"
                        value={currentUpdate?.subject || ''}
                        onChange={(e) => setCurrentUpdate({ ...currentUpdate, subject: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Title</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Page 24 Exercise"
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-purple-500"
                      value={currentUpdate?.title || ''}
                      onChange={(e) => setCurrentUpdate({ ...currentUpdate, title: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Description / Homework Details</label>
                    <textarea 
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-purple-500 h-32 resize-none"
                      value={currentUpdate?.description || ''}
                      onChange={(e) => setCurrentUpdate({ ...currentUpdate, description: e.target.value })}
                    ></textarea>
                  </div>

                  <div className="pt-6 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit" 
                      className="flex-1 py-3 bg-purple-600 text-white font-bold rounded-xl hover:bg-purple-700 shadow-lg shadow-purple-200 transition-all flex items-center justify-center gap-2"
                    >
                      <Check size={20} />
                      Post Update
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ManageHomework;
