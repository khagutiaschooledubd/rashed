import React, { useState, useEffect } from 'react';
import { Calendar, Plus, Trash2, Search, FileText, Upload } from 'lucide-react';
import { getAll, createItem, deleteItem } from '../../services/api';
import { motion, AnimatePresence } from 'motion/react';

interface Routine {
  id?: string;
  className: string;
  examName: string;
  image: string;
  createdAt?: any;
}

const ManageRoutines = () => {
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [newRoutine, setNewRoutine] = useState({
    className: '',
    examName: '',
    image: ''
  });

  const classes = ['Nursery', 'Play', 'One', 'Two', 'Three', 'Four', 'Five'];

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const data = await getAll<Routine>('routines');
      setRoutines(data.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
    } catch (error) {
      console.error('Error fetching routines:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoutine.className || !newRoutine.examName || !newRoutine.image) return;

    try {
      await createItem('routines', {
        ...newRoutine,
        createdAt: new Date()
      });
      setIsAdding(false);
      setNewRoutine({ className: '', examName: '', image: '' });
      fetchData();
    } catch (error) {
      alert('Error adding routine');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this routine?')) return;
    try {
      await deleteItem('routines', id);
      fetchData();
    } catch (error) {
      alert('Error deleting routine');
    }
  };

  const filteredRoutines = routines.filter(r => 
    r.className.toLowerCase().includes(searchTerm.toLowerCase()) || 
    r.examName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto font-bengali">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">পরীক্ষার রুটিন ম্যানেজমেন্ট</h1>
          <p className="text-gray-500 font-medium">শ্রেণী অনুযায়ী পরীক্ষার সময়সূচী আপলোড করুন</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 bg-[#002147] text-white px-6 py-4 rounded-2xl font-bold hover:bg-blue-900 transition-all shadow-xl shadow-blue-100"
        >
          <Plus size={20} />
          রুটিন যোগ করুন
        </button>
      </div>

      {/* Search */}
      <div className="mb-8 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm max-w-xl">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="শ্রেণী বা পরীক্ষার নাম দিয়ে খুঁজুন..." 
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-white rounded-3xl animate-pulse border border-gray-100" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {filteredRoutines.map((routine) => (
              <motion.div 
                key={routine.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden group hover:shadow-xl transition-all"
              >
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={routine.image} 
                    alt={routine.examName} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-4 py-2 bg-white/90 backdrop-blur text-[#002147] font-black text-xs rounded-xl shadow-sm">
                      Class: {routine.className}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-black text-gray-900 mb-1">{routine.examName}</h3>
                  <div className="flex justify-between items-center mt-6">
                    <div className="flex items-center gap-2 text-gray-400 text-xs font-bold">
                       <Calendar size={14} />
                       <span>{new Date(routine.createdAt?.seconds * 1000).toLocaleDateString()}</span>
                    </div>
                    <button 
                      onClick={() => handleDelete(routine.id!)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {filteredRoutines.length === 0 && (
            <div className="col-span-full p-20 text-center">
              <div className="flex flex-col items-center gap-4 text-gray-400">
                <FileText size={64} className="opacity-10" />
                <p className="text-xl font-bold">কোনো রুটিন পাওয়া যায়নি</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add Modal */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-10">
                <div className="flex items-center gap-4 mb-8">
                  <div className="p-4 bg-blue-50 text-blue-600 rounded-3xl">
                    <Calendar size={32} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-gray-900 leading-tight">নতুন রুটিন আপলোড</h2>
                    <p className="text-gray-500 font-medium">নিচের তথ্যগুলো পূরণ করে রুটিনটি সেভ করুন</p>
                  </div>
                </div>

                <form onSubmit={handleAdd} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">শ্রেণী নির্বাচন করুন</label>
                    <select 
                      required
                      className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                      value={newRoutine.className}
                      onChange={(e) => setNewRoutine({ ...newRoutine, className: e.target.value })}
                    >
                      <option value="">শ্রেণী সিলেক্ট করুন...</option>
                      {classes.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">পরীক্ষার নাম</label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                      placeholder="e.g. ১ম সাময়িক পরীক্ষা ২০২৪"
                      value={newRoutine.examName}
                      onChange={(e) => setNewRoutine({ ...newRoutine, examName: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                       <Upload size={16} /> রুটিন ছবির লিঙ্ক (Image URL)
                    </label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                      placeholder="https://example.com/routine.jpg"
                      value={newRoutine.image}
                      onChange={(e) => setNewRoutine({ ...newRoutine, image: e.target.value })}
                    />
                    <p className="text-[10px] text-gray-400 font-bold">টিপস: গুগল ড্রাইভ অথবা ইমেজ হোস্টিং সাইটে ছবি আপলোড করে লিঙ্ক এখানে দিন।</p>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button 
                      type="button" 
                      onClick={() => setIsAdding(false)}
                      className="flex-1 px-8 py-5 bg-gray-100 text-gray-700 font-bold rounded-[1.5rem] hover:bg-gray-200 transition-all"
                    >
                      বাতিল
                    </button>
                    <button 
                      type="submit" 
                      className="flex-1 px-8 py-5 bg-[#002147] text-white font-bold rounded-[1.5rem] hover:bg-blue-900 transition-all shadow-xl shadow-blue-100"
                    >
                      রুটিন সেভ করুন
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ManageRoutines;
