import React from 'react';
import { 
  BookOpen, 
  Calendar, 
  ClipboardCheck, 
  FileText, 
  Trophy,
  GraduationCap
} from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { getDirectImageUrl } from '../../lib/imageUtils';

const TeacherOverview = () => {
  const { profile } = useAuth();

  const teacherActions = [
    { label: 'হোমওয়ার্ক আপলোড', path: '/teacher/homework', icon: <BookOpen size={32} />, color: 'bg-purple-600', sub: 'ক্লাস ও বিষয় অনুযায়ী' },
    { label: 'পরীক্ষার রুটিন', path: '/teacher/routines', icon: <Calendar size={32} />, color: 'bg-blue-600', sub: 'সাময়িক ও বার্ষিক রুটিন' },
    { label: 'ইম্পর্টেন্ট পড়া', path: '/teacher/homework', icon: <FileText size={32} />, color: 'bg-orange-500', sub: 'টিপস ও প্রয়োজনীয় পড়া' },
    { label: 'ফলাফল ইনপুট', path: '/teacher/results', icon: <Trophy size={32} />, color: 'bg-green-600', sub: 'বিষয় ভিত্তিক রেজাল্ট' },
  ];

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-gray-800">শিক্ষক পোর্টাল</h2>
          <p className="text-gray-500 font-bold uppercase tracking-widest text-xs mt-1">Khagutia Primary School Teacher Panel</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-4 bg-white px-6 py-3 rounded-2xl shadow-sm border border-gray-100">
           <div className="text-right">
             <p className="text-xs font-bold text-gray-400">শিক্ষকের নামঃ</p>
             <p className="text-lg font-black text-blue-600">{profile?.name}</p>
           </div>
           <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 overflow-hidden border border-blue-100">
             {profile?.photoURL ? (
               <img 
                 src={getDirectImageUrl(profile.photoURL)} 
                 alt={profile.name} 
                 className="w-full h-full object-cover"
                 onError={(e) => {
                   e.currentTarget.style.display = 'none';
                   const parent = e.currentTarget.parentElement;
                   if (parent) {
                     // Fallback to icon
                     parent.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-graduation-cap"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"/></svg>';
                   }
                 }}
               />
             ) : (
               <GraduationCap size={28} />
             )}
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {teacherActions.map((action, i) => (
          <motion.div
            key={action.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Link 
              to={action.path}
              className="bg-white p-8 rounded-3xl shadow-sm hover:shadow-xl transition-all border border-gray-100 flex flex-col items-center text-center group cursor-pointer"
            >
              <div className={`${action.color} text-white p-5 rounded-2xl mb-4 group-hover:scale-110 group-hover:rotate-3 transition-transform shadow-lg`}>
                {action.icon}
              </div>
              <h3 className="text-xl font-black text-gray-800 mb-1">{action.label}</h3>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{action.sub}</p>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="bg-blue-600 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center justify-between shadow-xl shadow-blue-100">
        <div className="max-w-xl">
           <h3 className="text-2xl font-black mb-2">আজকের ক্লাসের রুটিন অনুযায়ী আপডেট দিন</h3>
           <p className="text-blue-100 font-bold">ছাত্র-ছাত্রীরা তাদের পোর্টাল থেকে আপনার আপলোড করা হোমওয়ার্ক ও তথ্য দেখতে পারবে।</p>
        </div>
        <Link to="/teacher/homework" className="mt-6 md:mt-0 bg-white text-blue-600 px-8 py-3 rounded-xl font-black shadow-lg hover:bg-gray-100 transition-colors">
          আপলোড শুরু করুন
        </Link>
      </div>
    </div>
  );
};

export default TeacherOverview;
