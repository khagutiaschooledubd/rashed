import React, { useState, useEffect } from 'react';
import { getAll } from '../services/api';
import { HomeWork } from '../types';
import { BookOpen, User, Calendar, GraduationCap } from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';

const DailyClassUpdate = () => {
  const [updates, setUpdates] = useState<HomeWork[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedClass, setSelectedClass] = useState('All');

  const classes = ['All', 'Play', 'Nursery', 'One', 'Two', 'Three', 'Four', 'Five'];

  useEffect(() => {
    const fetchUpdates = async () => {
      const data = await getAll<HomeWork>('homework');
      setUpdates(data);
      setLoading(false);
    };
    fetchUpdates();
  }, []);

  const filteredUpdates = selectedClass === 'All' 
    ? updates 
    : updates.filter(u => u.className === selectedClass);

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-black text-[#002147] mb-4">Daily Class Update</h2>
          <div className="w-24 h-1 bg-purple-600 mx-auto rounded-full"></div>
          <p className="text-gray-500 mt-4 font-medium">আজকের ক্লাসের পড়া ও বাড়ির কাজ এখান থেকে দেখুন।</p>
        </div>

        {/* Class Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {classes.map(c => (
            <button
              key={c}
              onClick={() => setSelectedClass(c)}
              className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
                selectedClass === c 
                ? 'bg-purple-600 text-white shadow-lg' 
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {c === 'All' ? 'সব ক্লাস' : `শ্রেণিঃ ${c}`}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <div key={i} className="h-64 bg-white animate-pulse rounded-2xl"></div>)}
          </div>
        ) : filteredUpdates.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl text-center shadow-sm border border-gray-100">
            <BookOpen size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 font-bold">আজকের কোনো আপডেট পাওয়া যায়নি।</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredUpdates.map((update, i) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                key={update.id} 
                className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow relative overflow-hidden group"
              >
                <div className="absolute top-0 left-0 w-1.5 h-full bg-purple-600"></div>
                <div className="flex justify-between items-start mb-6">
                   <div>
                     <span className="text-[10px] font-black uppercase text-purple-600 bg-purple-50 px-2 py-1 rounded-full mb-2 inline-block">
                       শ্রেণিঃ {update.className}
                     </span>
                     <h3 className="text-xl font-black text-gray-800">{update.subject}</h3>
                   </div>
                   <div className="text-right">
                     <p className="text-[10px] font-black text-gray-400 uppercase">পড়ার তারিখ</p>
                     <p className="text-sm font-bold text-gray-700">
                       {update.date ? format(update.date.toDate(), 'dd MMM, yyyy') : 'N/A'}
                     </p>
                   </div>
                </div>

                <div className="mb-6">
                  <h4 className="font-bold text-sm text-gray-800 mb-1">{update.title}</h4>
                  <p className="text-sm text-gray-600 line-clamp-3 leading-relaxed">{update.description}</p>
                </div>

                <div className="pt-4 border-t border-gray-50 flex items-center justify-between">
                   <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-gray-100 rounded-full">
                        <User size={14} className="text-gray-500" />
                      </div>
                      <span className="text-xs font-bold text-gray-500">{update.teacherName || 'শিক্ষক'}</span>
                   </div>
                   <button className="text-purple-600 font-black text-xs hover:underline uppercase tracking-tight">
                     বিস্তারিত দেখুন
                   </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DailyClassUpdate;
