import React, { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Send, MessageSquare, Clock, Facebook, Youtube } from 'lucide-react';
import { motion } from 'motion/react';
import { getById } from '../services/api';
import { SiteSettings } from '../types';

const Contact = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loadingSettings, setLoadingSettings] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const data = await getById<SiteSettings>('settings', 'general');
        if (data) setSettings(data);
      } catch (error) {
        console.error('Error loading settings:', error);
      } finally {
        setLoadingSettings(false);
      }
    };
    loadSettings();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
      setFormData({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-20 font-bengali">
      {/* Hero Section */}
      <div className="bg-[#002147] text-white py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-400 rounded-full translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
        </div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center mb-6"
          >
            <div className="p-4 bg-white/10 backdrop-blur-md rounded-3xl border border-white/20 text-blue-300">
              <MessageSquare size={40} />
            </div>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-black mb-4 tracking-tight"
          >
            যোগাযোগ করুন
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-blue-200 text-lg md:text-xl font-medium max-w-2xl mx-auto leading-relaxed"
          >
            আমাদের সাথে যেকোনো তথ্য বা পরামর্শের জন্য যোগাযোগ করতে পারেন। আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।
          </motion.p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-10 relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Contact Info Cards */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-1 space-y-6"
          >
            <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-gray-100 group hover:shadow-2xl transition-all">
              <div className="flex items-start gap-5">
                <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="text-xl font-black text-gray-900 mb-1">ফোন করুন</h4>
                  <p className="text-gray-500 font-bold">{settings?.contactPhone || '+৮৮০ ১৭০০-০০০০০০'}</p>
                  <p className="text-gray-400 text-sm">সকাল ৯টা - বিকেল ৪টা</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-gray-100 group hover:shadow-2xl transition-all">
              <div className="flex items-start gap-5">
                <div className="p-4 bg-red-50 text-red-600 rounded-2xl group-hover:bg-red-600 group-hover:text-white transition-colors">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="text-xl font-black text-gray-900 mb-1">ইমেইল করুন</h4>
                  <p className="text-gray-500 font-bold">{settings?.contactEmail || 'info@schoolname.com'}</p>
                  <p className="text-gray-400 text-sm">যেকোনো সময়</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-[2rem] shadow-xl border border-gray-100 group hover:shadow-2xl transition-all">
              <div className="flex items-start gap-5">
                <div className="p-4 bg-green-50 text-green-600 rounded-2xl group-hover:bg-green-600 group-hover:text-white transition-colors">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="text-xl font-black text-gray-900 mb-1">ঠিকানা</h4>
                  <p className="text-gray-500 font-bold leading-relaxed whitespace-pre-line">
                    {settings?.address || 'গ্রাম ও ডাকঘর: নাম, উপজেলা: নাম, \nজেলা: নাম, বাংলাদেশ।'}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-[#002147] p-8 rounded-[2rem] shadow-xl text-white">
              <h4 className="text-xl font-black mb-6">সামাজিক মাধ্যমে যুক্ত হোন</h4>
              <div className="flex gap-4">
                {settings?.facebookUrl && (
                  <a href={settings.facebookUrl} target="_blank" rel="noreferrer" className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center hover:bg-blue-600 hover:scale-110 transition-all border border-white/10">
                    <Facebook size={24} />
                  </a>
                )}
                {settings?.youtubeUrl && (
                  <a href={settings.youtubeUrl} target="_blank" rel="noreferrer" className="w-12 h-12 bg-white/10 backdrop-blur-md rounded-xl flex items-center justify-center hover:bg-red-600 hover:scale-110 transition-all border border-white/10">
                    <Youtube size={24} />
                  </a>
                )}
                {!settings?.facebookUrl && !settings?.youtubeUrl && (
                  <p className="text-blue-300 text-xs font-bold font-bengali">অ্যাডমিন প্যানেল থেকে সামাজিক মাধ্যমের লিঙ্ক যুক্ত করুন।</p>
                )}
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-2 bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl border border-gray-100"
          >
            <div className="flex items-center gap-4 mb-10">
              <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
                <Send size={32} />
              </div>
              <div>
                <h2 className="text-3xl font-black text-gray-900 tracking-tight">বার্তা পাঠান</h2>
                <p className="text-gray-500 font-medium font-bengali">আমরা ২৫ ঘণ্টার মধ্যে উত্তর দেওয়ার চেষ্টা করি</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">আপনার নাম</label>
                  <input 
                    type="text" 
                    required
                    placeholder="নাম লিখুন"
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold transition-all"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">ইমেইল / মোবাইল</label>
                  <input 
                    type="text" 
                    required
                    placeholder="ইমেইল বা মোবাইল নম্বর"
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold transition-all"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">বিষয়</label>
                <input 
                  type="text" 
                  required
                  placeholder="বার্তার বিষয়"
                  className="w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold transition-all"
                  value={formData.subject}
                  onChange={(e) => setFormData({...formData, subject: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">আপনার বার্তা</label>
                <textarea 
                  required
                  rows={5}
                  placeholder="এখানে আপনার বার্তা লিখুন..."
                  className="w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold transition-all resize-none"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                />
              </div>

              <button 
                type="submit" 
                disabled={status === 'sending' || status === 'success'}
                className={`w-full py-5 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-3 shadow-xl ${
                  status === 'success' 
                    ? 'bg-green-500 text-white shadow-green-100' 
                    : 'bg-[#002147] text-white hover:bg-blue-900 shadow-blue-100'
                }`}
              >
                {status === 'sending' ? (
                  <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : status === 'success' ? (
                  <>বার্তা পাঠানো হয়েছে!</>
                ) : (
                  <>
                    <Send size={22} />
                    বার্তা পাঠান
                  </>
                )}
              </button>
            </form>
          </motion.div>
        </div>

        {/* Map Placeholder */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="mt-12 bg-white p-4 rounded-[2.5rem] shadow-xl border border-gray-100 h-96 overflow-hidden"
        >
          <div className="w-full h-full bg-gray-100 rounded-[2rem] flex flex-col items-center justify-center text-gray-400 gap-4">
            <MapPin size={64} className="opacity-20" />
            <p className="font-bold text-lg">গুগল ম্যাপ লোকেশন লোড হচ্ছে...</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Contact;
