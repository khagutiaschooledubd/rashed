import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { LogIn, Lock, Mail, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

const Login = () => {
  const [idCode, setIdCode] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const roleFromUrl = searchParams.get('role') || 'guardian';

  const [isInitializing, setIsInitializing] = useState(false);

  const initializeDemoUsers = async () => {
    setIsInitializing(true);
    setError('');
    try {
      const { createUserWithEmailAndPassword } = await import('firebase/auth');
      const { setDoc, doc } = await import('firebase/firestore');
      
      const demoUsers = [
        { id: 'admin', email: 'admin@kps.edu.bd', pass: '$HahinaR@shed', role: 'admin', name: 'অ্যাডমিন ইউজার' },
        { id: 'teacher1', email: 'teacher1@kps.edu.bd', pass: 'teacher123', role: 'teacher', name: 'শিক্ষক ১' },
        { id: 'student1', email: 'student1@kps.edu.bd', pass: 'student123', role: 'student', name: 'শিক্ষার্থী ১' },
      ];

      for (const u of demoUsers) {
        try {
          // Try to sign in with the NEW password first to see if it's already updated
          try {
            await signInWithEmailAndPassword(auth, u.email, u.pass);
            console.log(`User ${u.id} is already using the new password.`);
            continue; // Already updated, move to next user
          } catch {
            // New password didn't work, proceed to create or update
          }

          // Try to create first
          const res = await createUserWithEmailAndPassword(auth, u.email, u.pass);
          await setDoc(doc(db, 'users', res.user.uid), {
            uid: res.user.uid,
            email: u.email,
            role: u.role,
            name: u.name,
            createdAt: new Date()
          }, { merge: true });
          console.log(`Created user: ${u.id}`);
        } catch (e: any) {
          if (e.code === 'auth/email-already-in-use') {
            try {
              // If already exists, try to login with old default password and update it to the new one
              const oldPass = u.id === 'admin' ? 'admin123' : u.id === 'teacher1' ? 'teacher123' : 'student123';
              const loginRes = await signInWithEmailAndPassword(auth, u.email, oldPass);
              const { updatePassword } = await import('firebase/auth');
              await updatePassword(loginRes.user, u.pass);
              
              // Also update firestore just in case
              await setDoc(doc(db, 'users', loginRes.user.uid), {
                email: u.email,
                role: u.role,
                name: u.name
              }, { merge: true });
              
              console.log(`Updated password for existing user: ${u.id}`);
            } catch (loginErr) {
              // If login fails, user might already have a different custom password
              console.log(`Synchronization skipped for ${u.id}: user exists but default password doesn't match.`);
            }
          } else {
            console.error(`Error processing ${u.id}:`, e);
          }
        }
      }
      setError('ইনিশিয়ালাইজেশন সম্পন্ন! অ্যাডমিন ইউজার ID: admin এবং পাসওয়ার্ড: $HahinaR@shed।');
    } catch (err: any) {
      console.error("Initialization Error:", err);
      if (err.code === 'auth/operation-not-allowed') {
        setError(`ত্রুটি: Firebase কনসোল থেকে Email/Password Authentication ইনেবল করা নেই। প্রজেক্ট আইডি: ${auth.app.options.projectId}`);
      } else {
        setError(`সেটআপে সমস্যা হয়েছে: ${err.message}`);
      }
    } finally {
      setIsInitializing(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const cleanId = idCode.trim();
      const cleanPass = password.trim();

      if (roleFromUrl === 'teacher') {
        const { collection, query, where, getDocs } = await import('firebase/firestore');
        const q = query(collection(db, 'teachers'), where('loginId', '==', cleanId), where('password', '==', cleanPass));
        const querySnapshot = await getDocs(q);
        
        console.log(`Teacher lookup for ${cleanId}: found ${querySnapshot.size} matches`);

        if (!querySnapshot.empty) {
          const teacherData = { id: querySnapshot.docs[0].id, ...querySnapshot.docs[0].data() } as any;
          localStorage.setItem('customUser', JSON.stringify({
            uid: `teacher_${teacherData.id}`,
            name: teacherData.name,
            email: teacherData.contact?.split('|')[0] || teacherData.loginId,
            role: 'teacher',
            teacherId: teacherData.id,
            photoURL: teacherData.image
          }));
          window.dispatchEvent(new Event('storage'));
          navigate('/teacher');
          return;
        }
      }

      if (roleFromUrl === 'guardian' || roleFromUrl === 'student') {
        const { collection, query, where, getDocs } = await import('firebase/firestore');
        const q = query(collection(db, 'students'), where('loginId', '==', cleanId), where('password', '==', cleanPass));
        const querySnapshot = await getDocs(q);
        
        console.log(`Student lookup for ${cleanId}: found ${querySnapshot.size} matches`);

        if (!querySnapshot.empty) {
          const studentData = { id: querySnapshot.docs[0].id, ...querySnapshot.docs[0].data() } as any;
          localStorage.setItem('customUser', JSON.stringify({
            uid: `student_${studentData.id}`,
            name: studentData.name,
            email: studentData.loginId,
            role: 'student',
            studentId: studentData.id,
            photoURL: studentData.image,
            rollNo: studentData.rollNo,
            className: studentData.className
          }));
          window.dispatchEvent(new Event('storage'));
          navigate('/student');
          return;
        }
      }

      // Default Firebase Auth flow
      const email = cleanId.includes('@') ? cleanId : `${cleanId}@kps.edu.bd`;
      const userCredential = await signInWithEmailAndPassword(auth, email, cleanPass);
      const user = userCredential.user;
      
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        const userRole = userDoc.data().role;
        if (userRole === 'admin') navigate('/admin');
        else if (userRole === 'teacher') navigate('/teacher');
        else if (userRole === 'student' || userRole === 'guardian') navigate('/student');
        else navigate('/');
      } else {
        setError('User profile not found.');
      }
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        setError(`সিস্টেম ত্রুটি: Firebase-এ Email/Password লগইন ইনেবল করা নেই। প্রজেক্ট আইডি: ${auth.app.options.projectId}`);
      } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setError('ভুল আইডি অথবা পাসওয়ার্ড দিয়েছেন। অনুগ্রহ করে সঠিক তথ্য দিয়ে পুনরায় চেষ্টা করুন।');
      } else {
        setError(`ত্রুটি: ${err.message}`);
      }
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getRoleTitle = () => {
    if (roleFromUrl === 'admin') return 'এ্যাডমিন পোর্টাল';
    if (roleFromUrl === 'teacher') return 'টিচার্স পোর্টাল';
    return 'গার্ডিয়ান/স্টুডেন্ট পোর্টাল';
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-gray-50 px-4 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 border border-gray-100"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black text-[#002147] mb-2">{getRoleTitle()}</h2>
          <p className="text-gray-500 font-medium">আপনার আইডি এবং পাসওয়ার্ড দিন</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 flex items-center gap-3">
            <AlertCircle size={20} />
            <span className="text-sm font-bold">{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">আইডি কোড (User ID)</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                required
                value={idCode}
                onChange={(e) => setIdCode(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                placeholder={roleFromUrl === 'admin' ? 'Admin ID' : roleFromUrl === 'teacher' ? 'Teacher ID' : 'Student Roll/ID'}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">পাসওয়ার্ড</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                placeholder="আপনার পাসওয়ার্ড"
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" />
              <span className="text-gray-600 font-medium">মনে রাখুন</span>
            </label>
            <a href="#" className="text-blue-600 font-bold hover:underline">পাসওয়ার্ড ভুলে গেছেন?</a>
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-[#002147] hover:bg-blue-900 text-white font-black py-4 rounded-xl shadow-lg transition-all transform hover:-translate-y-1 disabled:bg-gray-400 disabled:transform-none flex justify-center items-center gap-2"
          >
            {loading ? (
              <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                লগইন করুন
                <LogIn size={20} />
              </>
            )}
          </button>
        </form>


        <div className="mt-8 pt-6 border-t border-gray-100">
           <p className="text-center text-[10px] text-gray-400 mb-3 font-bold uppercase tracking-widest">System Setup (Run Once)</p>
           <button 
             onClick={initializeDemoUsers}
             disabled={isInitializing}
             className="w-full py-2 bg-gray-50 text-gray-400 text-[10px] font-black rounded-lg border border-dashed border-gray-200 hover:bg-gray-100 hover:text-gray-600 transition-all uppercase tracking-tighter"
           >
             {isInitializing ? 'ইনপুট হচ্ছে...' : 'Initialize Demo Accounts (Admin, Teacher, Student)'}
           </button>
        </div>

        <div className="mt-8 pt-6 border-t border-gray-100 text-center">
            <p className="text-gray-500 text-sm font-medium">
                আইডি নেই? <a href="#" className="text-blue-600 font-bold hover:underline">অ্যাডমিনের সাথে যোগাযোগ করুন</a>
            </p>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;
