import React from 'react';
import { useNavigate } from 'react-router-dom';
import { UserCog, UserSquare2, Users, GraduationCap, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

const LoginSelector = () => {
  const navigate = useNavigate();

  const roles = [
    {
      id: 'admin',
      title: 'এ্যাডমিন পোর্টাল',
      icon: <UserCog size={48} />,
      color: 'bg-blue-600',
      description: 'স্কুল ম্যানেজমেন্ট ও কনটেন্ট কন্ট্রোল'
    },
    {
      id: 'teacher',
      title: 'টিচার্স পোর্টাল',
      icon: <UserSquare2 size={48} />,
      color: 'bg-indigo-600',
      description: 'হোমওয়ার্ক ও রেজাল্ট আপলোড করুন'
    },
    {
      id: 'guardian',
      title: 'গার্ডিয়ানস পোর্টাল',
      icon: <Users size={48} />,
      color: 'bg-green-600',
      description: 'সন্তানের পড়া ও প্রগ্রেস দেখুন'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-black text-[#002147] mb-2 uppercase tracking-tight">লগইন করুন</h2>
        <p className="text-gray-500 font-bold">আপনার নির্দিষ্ট পোর্টালটি নির্বাচন করুন</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
        {roles.map((role, i) => (
          <motion.div
            key={role.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            onClick={() => navigate(`/auth/login?role=${role.id}`)}
            className="bg-white rounded-3xl shadow-xl p-8 cursor-pointer group hover:scale-105 transition-all border-b-8 border-transparent hover:border-blue-600"
          >
            <div className={`${role.color} w-24 h-24 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg transform group-hover:rotate-6 transition-transform`}>
              {role.icon}
            </div>
            <h3 className="text-2xl font-black text-gray-800 mb-3">{role.title}</h3>
            <p className="text-gray-500 text-sm font-medium mb-8">{role.description}</p>
            <div className="flex items-center gap-2 text-blue-600 font-black text-lg">
              প্রবেশ করুন <ArrowRight size={20} />
            </div>
          </motion.div>
        ))}
      </div>

      <button 
        onClick={() => navigate('/')}
        className="mt-12 text-gray-500 font-bold hover:text-blue-600 flex items-center gap-2"
      >
        ফিরে যান হোমে
      </button>
    </div>
  );
};

export default LoginSelector;
