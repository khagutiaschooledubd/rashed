import React, { useState } from 'react';
import { Search, FileText, User, BookOpen, GraduationCap, Award, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ExamResult } from '../types';

const Results = () => {
  const [searchId, setSearchId] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId) return;

    setLoading(true);
    setSearched(true);
    try {
      const q = query(collection(db, 'results'), where('rollNo', '==', searchId));
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ExamResult));
      setResults(data);
    } catch (error) {
      console.error('Error searching results:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-20 font-bengali">
      {/* Hero Section */}
      <div className="bg-[#002147] text-white py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400 rounded-full translate-x-1/2 translate-y-1/2 blur-3xl"></div>
        </div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-center mb-6"
          >
            <div className="p-4 bg-white/10 backdrop-blur-md rounded-3xl border border-white/20">
              <GraduationCap size={40} className="text-blue-300" />
            </div>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-black mb-4 tracking-tight"
          >
            পরীক্ষার ফলাফল
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-blue-200 text-lg md:text-xl font-medium max-w-2xl mx-auto leading-relaxed"
          >
            শিক্ষার্থীর রোল নম্বর দিয়ে আপনার ফলাফল সার্চ করুন।
          </motion.p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 -mt-10 relative z-20">
        {/* Search Bar */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white p-6 md:p-10 rounded-[2.5rem] shadow-2xl border border-gray-100 mb-12"
        >
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400" size={24} />
              <input 
                type="text" 
                placeholder="রোল নম্বর লিখুন (e.g. 101)" 
                className="w-full pl-14 pr-6 py-5 bg-gray-50 border border-gray-200 rounded-3xl outline-none focus:ring-2 focus:ring-blue-500 text-xl font-bold transition-all"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
              />
            </div>
            <button 
              type="submit" 
              className="px-10 py-5 bg-[#002147] text-white font-bold rounded-3xl hover:bg-blue-900 transition-all shadow-xl shadow-blue-100 flex items-center justify-center gap-3"
            >
              {loading ? (
                <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <Search size={22} />
                  ফলাফল দেখুন
                </>
              )}
            </button>
          </form>
        </motion.div>

        {/* Results Area */}
        <AnimatePresence mode="wait">
          {loading ? (
            <motion.div 
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
            >
              {[1, 2].map(i => (
                <div key={i} className="h-32 bg-white rounded-[2rem] animate-pulse shadow-sm" />
              ))}
            </motion.div>
          ) : searched ? (
            results.length > 0 ? (
              <motion.div 
                key="results"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-xl overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 -translate-y-1/2 translate-x-1/2 rounded-full blur-2xl opacity-50"></div>
                  
                  <div className="flex flex-col md:flex-row justify-between md:items-center gap-6 mb-10 pb-6 border-b border-gray-100">
                    <div className="flex items-center gap-4">
                      <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
                        <User size={32} />
                      </div>
                      <div>
                        <h2 className="text-3xl font-black text-gray-900">{results[0].studentName}</h2>
                        <p className="text-gray-500 font-bold">Class: {results[0].className} | Roll: {results[0].rollNo}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 px-6 py-3 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100">
                      <Calendar size={20} />
                      <span className="font-black">{results[0].examName}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    {results.map((res, i) => (
                      <motion.div 
                        key={res.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex items-center justify-between p-5 bg-gray-50 rounded-2xl border border-gray-100 hover:border-blue-200 transition-colors group"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white rounded-xl border border-gray-200 flex items-center justify-center text-gray-400 group-hover:text-blue-500 transition-colors">
                            <BookOpen size={24} />
                          </div>
                          <span className="text-xl font-bold text-gray-800">{res.subject}</span>
                        </div>
                        <div className="flex items-center gap-8">
                          <div className="text-right">
                            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Marks</p>
                            <p className="text-2xl font-black text-gray-900">{res.marks}</p>
                          </div>
                          <div className="w-16 h-16 bg-white rounded-2xl border-2 border-blue-100 flex items-center justify-center shadow-sm">
                            <span className={`text-2xl font-black ${
                              res.grade === 'A+' ? 'text-green-600' : 
                              res.grade === 'F' ? 'text-red-600' : 
                              'text-blue-600'
                            }`}>
                              {res.grade}
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="empty"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white p-20 rounded-[2.5rem] text-center shadow-xl border border-gray-100"
              >
                <FileText size={80} className="mx-auto text-gray-100 mb-8" />
                <h3 className="text-2xl font-black text-gray-800 mb-2">ফলাফল পাওয়া যায়নি</h3>
                <p className="text-gray-500 text-lg">আপনার ইনপুট করা রোল নম্বরটি সঠিক কি না তা আবার পরীক্ষা করুন।</p>
              </motion.div>
            )
          ) : (
            <motion.div 
              key="guide"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              <div className="bg-white/60 backdrop-blur-sm p-8 rounded-[2rem] border border-white flex items-start gap-4">
                <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
                  <Search size={24} />
                </div>
                <div>
                  <h4 className="font-black text-gray-800 mb-1">সহজে খুঁজুন</h4>
                  <p className="text-sm text-gray-500">আপনার ব্যক্তিগত রোল নম্বর ব্যবহার করে সার্চ করুন।</p>
                </div>
              </div>
              <div className="bg-white/60 backdrop-blur-sm p-8 rounded-[2rem] border border-white flex items-start gap-4">
                <div className="p-3 bg-amber-100 text-amber-600 rounded-xl">
                  <Award size={24} />
                </div>
                <div>
                  <h4 className="font-black text-gray-800 mb-1">গ্রেড ও নম্বর</h4>
                  <p className="text-sm text-gray-500">প্রতিটি বিষয়ের নম্বর ও গ্রেড বিস্তারিত দেখুন।</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Results;
