import React, { useState, useEffect } from 'react';
import { getAll } from '../services/api';
import { Notice } from '../types';
import { Bell, Calendar, Download, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';

const NoticeBoard = () => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNotices = async () => {
      const data = await getAll<Notice>('notices');
      setNotices(data);
      setLoading(false);
    };
    fetchNotices();
  }, []);

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-black text-[#002147] mb-4">নোটিশ বোর্ড</h2>
          <div className="w-24 h-1 bg-red-600 mx-auto rounded-full"></div>
          <p className="text-gray-500 mt-4 font-medium">বিদ্যালয়ের সর্বশেষ নোটিশ ও তথ্যাবলী এখানে পাবেন।</p>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => <div key={i} className="h-24 bg-white animate-pulse rounded-xl border border-gray-100"></div>)}
          </div>
        ) : notices.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl text-center shadow-sm border border-gray-100">
            <Bell size={48} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 font-bold">এখন পর্যন্ত কোনো নোটিশ প্রদান করা হয়নি।</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {notices.map((notice, i) => (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                key={notice.id} 
                className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex flex-col md:flex-row md:items-center gap-6"
              >
                <div className="bg-blue-50 text-blue-700 p-4 rounded-xl flex flex-col items-center justify-center min-w-[100px]">
                   <Calendar size={24} className="mb-1" />
                   <span className="text-lg font-black">{notice.date ? format(notice.date.toDate(), 'dd MMM') : 'N/A'}</span>
                   <span className="text-[10px] font-bold uppercase">{notice.date ? format(notice.date.toDate(), 'yyyy') : ''}</span>
                </div>
                <div className="flex-1">
                   <div className="flex items-center gap-2 mb-2">
                     <span className="bg-orange-100 text-orange-700 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                       {notice.category || 'General'}
                     </span>
                   </div>
                   <h3 className="text-xl font-black text-gray-800 mb-2">{notice.title}</h3>
                   <p className="text-gray-600 text-sm line-clamp-2">{notice.content}</p>
                </div>
                <div className="flex gap-3">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 text-sm transition-colors">
                    বিস্তারিত <ChevronRight size={16} />
                  </button>
                  <button className="p-2.5 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg transition-colors">
                    <Download size={20} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NoticeBoard;
