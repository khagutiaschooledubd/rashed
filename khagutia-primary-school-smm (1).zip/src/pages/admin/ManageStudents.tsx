import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Users, 
  Trash2, 
  Edit,
  X,
  Check,
  User,
  Phone,
  Download,
  FileSpreadsheet
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { getAll, createItem, updateItem, deleteItem } from '../../services/api';
import { StudentProfile } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { getDirectImageUrl } from '../../lib/imageUtils';

const ManageStudents = () => {
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<Partial<StudentProfile> | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    setLoading(true);
    const data = await getAll<StudentProfile>('students');
    setStudents(data);
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentStudent) return;

    if (currentStudent.id) {
      await updateItem('students', currentStudent.id, currentStudent);
    } else {
      await createItem('students', currentStudent);
    }
    
    setIsModalOpen(false);
    loadStudents();
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this student?')) {
      await deleteItem('students', id);
      loadStudents();
    }
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.rollNo.includes(searchTerm)
  );

  const classesList = ['Play', 'Nursery', 'One', 'Two', 'Three', 'Four', 'Five'];

  const downloadExcel = (className: string) => {
    const classStudents = students.filter(s => s.className === className);
    
    if (classStudents.length === 0) {
      alert(`Class ${className} এ কোনো স্টুডেন্ট পাওয়া যায়নি।`);
      return;
    }

    const data = classStudents.map(s => ({
      'Student ID': s.id,
      'Roll No': s.rollNo,
      'Name': s.name,
      'Class': s.className,
      'Guardian Name': s.guardianName,
      'Phone': s.guardianPhone,
      'Address': s.address || 'N/A',
      'Photo URL': s.image || 'N/A'
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, `Class ${className}`);
    
    XLSX.writeFile(workbook, `Student_List_${className}_${new Date().toLocaleDateString()}.xlsx`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-gray-800">Manage Students</h2>
          <p className="text-gray-500 font-medium">Add and manage student records</p>
        </div>
        <button 
          onClick={() => { setCurrentStudent({}); setIsModalOpen(true); }}
          className="bg-green-600 hover:bg-green-700 text-white px-6 py-4 rounded-2xl font-bold flex items-center gap-2 shadow-xl shadow-green-100 transition-all hover:-translate-y-1"
        >
          <Plus size={20} />
          Add New Student
        </button>
      </div>

      {/* Download Section */}
      <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
            <Download size={24} />
          </div>
          <h3 className="text-xl font-bold text-gray-800">স্টুডেন্ট লিস্ট ডাউনলোড (ক্লাস অনুযায়ী)</h3>
        </div>
        
        <div className="flex flex-wrap gap-3">
          {classesList.map((cls) => (
            <button
              key={cls}
              onClick={() => downloadExcel(cls)}
              className="flex items-center gap-2 px-6 py-3 bg-gray-50 hover:bg-blue-600 hover:text-white text-gray-700 font-bold rounded-xl transition-all border border-gray-100 group"
            >
              <span>Class {cls}</span>
              <FileSpreadsheet size={18} className="text-gray-400 group-hover:text-white transition-colors" />
            </button>
          ))}
        </div>
      </div>

      {/* Search & Filter */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center gap-3">
        <Search size={20} className="text-gray-400" />
        <input 
          type="text" 
          placeholder="Search by name, class or roll..." 
          className="flex-1 outline-none text-sm font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Students Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 text-gray-500 text-xs font-black uppercase tracking-wider">
                <th className="px-6 py-4">Student</th>
                <th className="px-6 py-4">Class</th>
                <th className="px-6 py-4">Roll</th>
                <th className="px-6 py-4">Guardian</th>
                <th className="px-6 py-4">Phone</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                [1, 2, 3].map(i => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={6} className="px-6 py-4"><div className="h-8 bg-gray-100 rounded"></div></td>
                  </tr>
                ))
              ) : filteredStudents.map((student) => (
                <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {student.image ? (
                        <img 
                          src={getDirectImageUrl(student.image)} 
                          alt={student.name} 
                          className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(student.name)}&background=random`;
                          }}
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-xs font-bold border-2 border-white shadow-sm">
                          {student.name.charAt(0)}
                        </div>
                      )}
                      <span className="font-bold text-gray-800">{student.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-blue-600">{student.className}</td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-600">{student.rollNo}</td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-600">{student.guardianName}</td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-600">{student.guardianPhone}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                       <button 
                         onClick={() => { setCurrentStudent(student); setIsModalOpen(true); }}
                         className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                       >
                         <Edit size={18} />
                       </button>
                       <button 
                         onClick={() => handleDelete(student.id)}
                         className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                       >
                         <Trash2 size={18} />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            ></motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-black text-gray-800">
                    {currentStudent?.id ? 'Edit Student' : 'Add New Student'}
                  </h3>
                  <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSave} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
                      <input 
                        type="text" 
                        required
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.name || ''}
                        onChange={(e) => setCurrentStudent({ ...currentStudent, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Roll No</label>
                      <input 
                        type="text" 
                        required
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.rollNo || ''}
                        onChange={(e) => setCurrentStudent({ ...currentStudent, rollNo: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Photo URL (ছবির লিঙ্ক)</label>
                    <div className="flex gap-4">
                      <input 
                        type="text" 
                        className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.image || ''}
                        placeholder="https://drive.google.com/file/d/..."
                        onChange={(e) => setCurrentStudent({ ...currentStudent, image: e.target.value })}
                      />
                      {currentStudent?.image && (
                        <div className="w-14 h-14 rounded-2xl bg-gray-100 overflow-hidden border border-gray-200 shadow-sm shrink-0">
                          <img 
                            src={getDirectImageUrl(currentStudent.image)} 
                            alt="Preview" 
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/150?text=Error")}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Class</label>
                    <select 
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                      value={currentStudent?.className || ''}
                      onChange={(e) => setCurrentStudent({ ...currentStudent, className: e.target.value })}
                      required
                    >
                      <option value="">Select Class</option>
                      <option value="Play">Play</option>
                      <option value="Nursery">Nursery</option>
                      <option value="One">One</option>
                      <option value="Two">Two</option>
                      <option value="Three">Three</option>
                      <option value="Four">Four</option>
                      <option value="Five">Five</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Guardian Name</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.guardianName || ''}
                        onChange={(e) => setCurrentStudent({ ...currentStudent, guardianName: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Guardian Phone</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.guardianPhone || ''}
                        onChange={(e) => setCurrentStudent({ ...currentStudent, guardianPhone: e.target.value })}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Address (ঠিকানা)</label>
                    <textarea 
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                      rows={2}
                      value={currentStudent?.address || ''}
                      onChange={(e) => setCurrentStudent({ ...currentStudent, address: e.target.value })}
                      placeholder="Enter student address..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Login ID (উজার আইডি) <span className="text-red-500">*</span></label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.loginId || ''}
                        required
                        placeholder="e.g. STU001"
                        onChange={(e) => setCurrentStudent({ ...currentStudent, loginId: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Password (পাসওয়ার্ড) <span className="text-red-500">*</span></label>
                      <input 
                        type="password" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentStudent?.password || ''}
                        required
                        placeholder="••••••••"
                        onChange={(e) => setCurrentStudent({ ...currentStudent, password: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="pt-6 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit" 
                      className="flex-1 py-3 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 shadow-lg shadow-green-200 transition-all flex items-center justify-center gap-2"
                    >
                      <Check size={20} />
                      Save Student
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ManageStudents;
