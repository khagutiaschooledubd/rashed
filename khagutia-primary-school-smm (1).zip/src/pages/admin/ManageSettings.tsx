import React, { useState, useEffect } from 'react';
import { getById } from '../../services/api';
import { SiteSettings } from '../../types';
import { Save, Check, AlertCircle, Info, Image as ImageIcon, Globe, MapPin, Phone, Mail, Plus, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { setDoc, doc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { getDirectImageUrl } from '../../lib/imageUtils';

const ManageSettings = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const data = await getById<SiteSettings>('settings', 'general');
    if (data) {
      setSettings(data);
    } else {
      setSettings({
        schoolName: 'Khagutia Primary School',
        headTeacherName: 'শাহিনা পারভিন',
        headTeacherMessage: '',
        headTeacherImage: '',
        contactEmail: 'info@khagutiaschool.edu.bd',
        contactPhone: '01787 593234',
        address: 'খাগুটিয়া, ঝালকাঠি, বাংলাদেশ',
        aboutText: '',
        logoUrl: '',
        bannerUrl: '',
        facebookUrl: '',
        youtubeUrl: '',
        scrollingNotice: '',
        govLogoUrl: '',
        heroSlides: [
          {
            image: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=2000&auto=format&fit=crop',
            title: 'শিক্ষাই জাতির মেরুদণ্ড',
            subtitle: 'সুস্থ, সুন্দর ও আলোকিত ভবিষ্যৎ গড়তে আমরা প্রতিজ্ঞাবদ্ধ।'
          }
        ]
      });
    }
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    
    try {
      await setDoc(doc(db, 'settings', 'general'), settings);
      setMessage('Settings updated successfully!');
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      console.error(err);
      setMessage('Failed to update settings.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="animate-pulse h-96 bg-gray-100 rounded-[2rem]"></div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">সাইট সেটিংস</h2>
          <p className="text-gray-500 font-medium">স্কুলের লোগো, ব্যানার এবং কন্টাক্ট ইনফো ম্যানেজ করুন</p>
        </div>
      </div>

      {message && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl flex items-center gap-3 font-bold text-sm ${
            message.includes('successfully') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}
        >
          {message.includes('successfully') ? <Check size={18} /> : <AlertCircle size={18} />}
          {message}
        </motion.div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Visual Assets Section */}
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-8">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-purple-50 text-purple-600 rounded-2xl">
              <ImageIcon size={24} />
            </div>
            <h3 className="text-xl font-bold text-gray-800">ব্র্যান্ডিং ও ব্যানার (Logo & Banner)</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700">স্কুল লোগো (Logo URL)</label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-purple-500 transition-all font-mono text-xs"
                placeholder="https://..."
                value={settings?.logoUrl || ''}
                onChange={(e) => setSettings({ ...settings!, logoUrl: e.target.value })}
              />
              <div className="p-6 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center">
                {settings?.logoUrl ? (
                  <img 
                    src={getDirectImageUrl(settings.logoUrl)} 
                    alt="Logo Preview" 
                    className="h-24 w-auto object-contain"
                  />
                ) : (
                  <div className="text-gray-400 text-center">
                    <Globe size={40} className="mx-auto mb-2 opacity-20" />
                    <p className="text-xs font-bold">লোগো প্রিভিউ দেখা যাবে</p>
                  </div>
                )}
              </div>
              <button 
                type="button"
                onClick={() => setSettings({ ...settings!, logoUrl: '' })}
                className="w-full py-2 text-red-500 text-xs font-bold hover:bg-red-50 rounded-xl transition-colors"
              >
                লোগো রিমুভ করুন
              </button>
            </div>

            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700">হোম পেজ ব্যানার (Banner URL)</label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-purple-500 transition-all font-mono text-xs"
                placeholder="https://..."
                value={settings?.bannerUrl || ''}
                onChange={(e) => setSettings({ ...settings!, bannerUrl: e.target.value })}
              />
              <div className="p-2 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 overflow-hidden aspect-video flex items-center justify-center">
                {settings?.bannerUrl ? (
                  <img 
                    src={getDirectImageUrl(settings.bannerUrl)} 
                    alt="Banner Preview" 
                    className="w-full h-full object-cover rounded-xl"
                  />
                ) : (
                  <div className="text-gray-400 text-center">
                    <ImageIcon size={40} className="mx-auto mb-2 opacity-20" />
                    <p className="text-xs font-bold">ব্যানার প্রিভিউ দেখা যাবে</p>
                  </div>
                )}
              </div>
              <button 
                type="button"
                onClick={() => setSettings({ ...settings!, bannerUrl: '' })}
                className="w-full py-2 text-red-500 text-xs font-bold hover:bg-red-50 rounded-xl transition-colors"
              >
                ব্যানার রিমুভ করুন
              </button>
            </div>

            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700">সরকারি লোগো (Gov Logo URL)</label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-purple-500 transition-all font-mono text-xs"
                placeholder="https://..."
                value={settings?.govLogoUrl || ''}
                onChange={(e) => setSettings({ ...settings!, govLogoUrl: e.target.value })}
              />
              <div className="p-6 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center">
                {settings?.govLogoUrl ? (
                  <img 
                    src={getDirectImageUrl(settings.govLogoUrl)} 
                    alt="Gov Logo Preview" 
                    className="h-24 w-auto object-contain"
                  />
                ) : (
                  <div className="text-gray-400 text-center">
                    <Globe size={40} className="mx-auto mb-2 opacity-20" />
                    <p className="text-xs font-bold">লোগো প্রিভিউ দেখা যাবে</p>
                  </div>
                )}
              </div>
              <button 
                type="button"
                onClick={() => setSettings({ ...settings!, govLogoUrl: '' })}
                className="w-full py-2 text-red-500 text-xs font-bold hover:bg-red-50 rounded-xl transition-colors"
              >
                লোগো রিমুভ করুন
              </button>
            </div>
          </div>
        </div>

        {/* Hero Slides Section */}
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center justify-between gap-4 mb-2">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-red-50 text-red-600 rounded-2xl">
                <ImageIcon size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-800">হোম পেজ স্লাইডার (Hero Slides)</h3>
            </div>
            <button 
              type="button"
              onClick={() => {
                const newSlides = [...(settings?.heroSlides || []), { image: '', title: '', subtitle: '' }];
                setSettings({ ...settings!, heroSlides: newSlides });
              }}
              className="flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-xl font-bold hover:bg-blue-100 transition-colors"
            >
              <Plus size={18} /> আর একটি যোগ করুন
            </button>
          </div>

          <div className="space-y-8">
            {(settings?.heroSlides || []).map((slide, index) => (
              <div key={index} className="p-6 bg-gray-50 rounded-3xl border border-gray-100 space-y-6 relative group">
                <button 
                  type="button"
                  onClick={() => {
                    const newSlides = settings?.heroSlides?.filter((_, i) => i !== index);
                    setSettings({ ...settings!, heroSlides: newSlides });
                  }}
                  className="absolute top-4 right-4 p-2 text-red-500 hover:bg-red-50 rounded-xl opacity-0 group-hover:opacity-100 transition-all shadow-sm bg-white"
                >
                  <Trash2 size={18} />
                </button>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">Image URL</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs"
                        placeholder="https://..."
                        value={slide.image}
                        onChange={(e) => {
                          const newSlides = [...(settings?.heroSlides || [])];
                          newSlides[index].image = e.target.value;
                          setSettings({ ...settings!, heroSlides: newSlides });
                        }}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">Title (Bangla)</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                        value={slide.title}
                        onChange={(e) => {
                          const newSlides = [...(settings?.heroSlides || [])];
                          newSlides[index].title = e.target.value;
                          setSettings({ ...settings!, heroSlides: newSlides });
                        }}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">Subtitle (Bangla)</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                        value={slide.subtitle}
                        onChange={(e) => {
                          const newSlides = [...(settings?.heroSlides || [])];
                          newSlides[index].subtitle = e.target.value;
                          setSettings({ ...settings!, heroSlides: newSlides });
                        }}
                      />
                    </div>
                  </div>
                  <div className="relative aspect-video rounded-2xl overflow-hidden bg-gray-200 border border-gray-200 group-hover:shadow-lg transition-all">
                    {slide.image ? (
                      <img src={getDirectImageUrl(slide.image)} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400">
                        <ImageIcon size={48} className="opacity-20" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {(settings?.heroSlides || []).length === 0 && (
              <div className="text-center py-12 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                <ImageIcon size={48} className="mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500 font-bold">কোন স্লাইড যোগ করা হয়নি</p>
              </div>
            )}
          </div>
        </div>

        {/* About Page Content */}
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
              <Info size={24} />
            </div>
            <h3 className="text-xl font-bold text-gray-800">আমাদের সম্পর্কে পেজ কন্টেন্ট</h3>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">আমাদের পরিচিতি ও ইতিহাস</label>
              <textarea 
                rows={5}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                value={settings?.aboutHistory || ''}
                onChange={(e) => setSettings({ ...settings!, aboutHistory: e.target.value })}
                placeholder="এখানে স্কুলের ইতিহাস ও পরিচিতি লিখুন..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">আমাদের লক্ষ্য (Vision)</label>
                <textarea 
                  rows={4}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                  value={settings?.aboutVision || ''}
                  onChange={(e) => setSettings({ ...settings!, aboutVision: e.target.value })}
                  placeholder="আমাদের ভিশন কি হবে..."
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">আমাদের মিশন (Mission)</label>
                <textarea 
                  rows={4}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
                  value={settings?.aboutMission || ''}
                  onChange={(e) => setSettings({ ...settings!, aboutMission: e.target.value })}
                  placeholder="আমাদের মিশন কি হবে..."
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 mb-2 uppercase">আমাদের সম্পর্কে পেজের ছবি (School Image)</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input 
                  type="text" 
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs"
                  placeholder="ছবি'র লিঙ্ক দিন..."
                  value={settings?.aboutImageUrl || ''}
                  onChange={(e) => setSettings({ ...settings!, aboutImageUrl: e.target.value })}
                />
                {settings?.aboutImageUrl && (
                  <div className="h-40 relative rounded-xl overflow-hidden border border-gray-200">
                    <img src={getDirectImageUrl(settings.aboutImageUrl)} alt="About Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* School Info */}
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
              <Info size={24} />
            </div>
            <h3 className="text-xl font-bold text-gray-800">স্কুল কন্টাক্ট ইনফো (Contact Details)</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                <Mail size={16} /> ইমেইল
              </label>
              <input 
                type="email" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                value={settings?.contactEmail || ''}
                onChange={(e) => setSettings({ ...settings!, contactEmail: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
                <Phone size={16} /> ফোন নম্বর
              </label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                value={settings?.contactPhone || ''}
                onChange={(e) => setSettings({ ...settings!, contactPhone: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2 flex items-center gap-2">
              <MapPin size={16} /> ঠিকানা (Physical Address)
            </label>
            <input 
              type="text" 
              className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              value={settings?.address || ''}
              onChange={(e) => setSettings({ ...settings!, address: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-gray-50">
            <div>
              <label className="block text-sm font-bold text-gray-100 mb-2 flex items-center gap-2 px-3 py-1 bg-blue-600 rounded-lg w-fit">
                Facebook URL
              </label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs"
                placeholder="https://facebook.com/..."
                value={settings?.facebookUrl || ''}
                onChange={(e) => setSettings({ ...settings!, facebookUrl: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-100 mb-2 flex items-center gap-2 px-3 py-1 bg-red-600 rounded-lg w-fit">
                YouTube URL
              </label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-mono text-xs"
                placeholder="https://youtube.com/..."
                value={settings?.youtubeUrl || ''}
                onChange={(e) => setSettings({ ...settings!, youtubeUrl: e.target.value })}
              />
            </div>
          </div>
          <div className="pt-6 border-t border-gray-100">
            <label className="block text-sm font-bold text-gray-700 mb-2 font-bengali">
              হেডার নোটিশ (Scrolling Notice)
            </label>
            <textarea 
              className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold h-24 resize-none"
              placeholder="যেমনঃ ২০২৬ শিক্ষাবর্ষে ভর্তি চলছে..."
              value={settings?.scrollingNotice || ''}
              onChange={(e) => setSettings({ ...settings!, scrollingNotice: e.target.value })}
            />
          </div>
        </div>

        {/* About School Section */}
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-green-50 text-green-600 rounded-2xl">
              <Info size={24} />
            </div>
            <h3 className="text-xl font-bold text-gray-800 font-bengali">স্কুল সম্পর্কিত তথ্য (About School)</h3>
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2 font-bengali">বিস্তারিত লিখুন (Bangla)</label>
            <textarea 
              className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-green-500 h-48 resize-none transition-all leading-relaxed"
              value={settings?.aboutText || ''}
              onChange={(e) => setSettings({ ...settings!, aboutText: e.target.value })}
            ></textarea>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <button 
            type="submit" 
            disabled={saving}
            className="bg-[#002147] hover:bg-blue-900 text-white px-12 py-4 rounded-2xl font-bold flex items-center gap-3 shadow-xl transition-all transform hover:-translate-y-1 disabled:bg-gray-400 disabled:transform-none group"
          >
            {saving ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <Save size={20} className="group-hover:scale-110 transition-transform" />
                সেভ করুন
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ManageSettings;
