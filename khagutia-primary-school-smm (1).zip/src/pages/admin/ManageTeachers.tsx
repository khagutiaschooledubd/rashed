import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  UserSquare2, 
  Mail, 
  Phone, 
  Trash2, 
  Edit,
  X,
  Check
} from 'lucide-react';
import { getAll, createItem, updateItem, deleteItem } from '../../services/api';
import { TeacherProfile } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { getDirectImageUrl } from '../../lib/imageUtils';

const ManageTeachers = () => {
  const [teachers, setTeachers] = useState<TeacherProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentTeacher, setCurrentTeacher] = useState<Partial<TeacherProfile> | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadTeachers();
  }, []);

  const loadTeachers = async () => {
    setLoading(true);
    const data = await getAll<TeacherProfile>('teachers');
    setTeachers(data);
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTeacher) return;

    if (currentTeacher.id) {
      await updateItem('teachers', currentTeacher.id, currentTeacher);
    } else {
      await createItem('teachers', currentTeacher);
    }
    
    setIsModalOpen(false);
    loadTeachers();
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this teacher?')) {
      await deleteItem('teachers', id);
      loadTeachers();
    }
  };

  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.designation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-gray-800">Manage Teachers</h2>
          <p className="text-gray-500 font-medium">Add and manage teaching staff</p>
        </div>
        <button 
          onClick={() => { setCurrentTeacher({}); setIsModalOpen(true); }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-transform hover:-translate-y-1"
        >
          <Plus size={20} />
          Add New Teacher
        </button>
      </div>

      {/* Search & Filter */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center gap-3">
        <Search size={20} className="text-gray-400" />
        <input 
          type="text" 
          placeholder="Search by name or designation..." 
          className="flex-1 outline-none text-sm font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Teachers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {loading ? (
          [1, 2, 3].map(i => <div key={i} className="h-64 bg-gray-200 animate-pulse rounded-2xl"></div>)
        ) : filteredTeachers.map((teacher) => (
          <motion.div 
            layout
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            key={teacher.id} 
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden group"
          >
            <div className="p-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-20 h-20 rounded-2xl overflow-hidden shadow-md">
                   <img 
                     src={getDirectImageUrl(teacher.image) || `https://ui-avatars.com/api/?name=${teacher.name}&background=random`} 
                     alt={teacher.name} 
                     className="w-full h-full object-cover"
                   />
                </div>
                <div>
                  <h4 className="text-lg font-black text-gray-800">{teacher.name}</h4>
                  <p className="text-sm font-bold text-blue-600 uppercase tracking-tight">{teacher.designation}</p>
                </div>
              </div>

              <div className="space-y-3 text-sm font-medium text-gray-600">
                <div className="flex items-center gap-3">
                  <Mail size={16} className="text-gray-400" />
                  <span>{teacher.contact?.split('|')[0] || 'N/A'}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone size={16} className="text-gray-400" />
                  <span>{teacher.contact?.split('|')[1] || 'N/A'}</span>
                </div>
              </div>

              <div className="mt-8 flex gap-2">
                <button 
                  onClick={() => { setCurrentTeacher(teacher); setIsModalOpen(true); }}
                  className="flex-1 flex items-center justify-center gap-2 py-2 bg-gray-50 hover:bg-blue-50 text-gray-600 hover:text-blue-600 rounded-lg font-bold transition-colors border border-transparent hover:border-blue-100"
                >
                  <Edit size={16} />
                  Edit
                </button>
                <button 
                  onClick={() => handleDelete(teacher.id)}
                  className="w-10 flex items-center justify-center bg-gray-50 hover:bg-red-50 text-gray-400 hover:text-red-500 rounded-lg transition-colors border border-transparent hover:border-red-100"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            ></motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-black text-gray-800">
                    {currentTeacher?.id ? 'Edit Teacher' : 'Add New Teacher'}
                  </h3>
                  <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSave} className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                      value={currentTeacher?.name || ''}
                      onChange={(e) => setCurrentTeacher({ ...currentTeacher, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Designation</label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                      value={currentTeacher?.designation || ''}
                      onChange={(e) => setCurrentTeacher({ ...currentTeacher, designation: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Phone</label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentTeacher?.contact?.split('|')[1] || ''}
                        onChange={(e) => {
                          const old = currentTeacher?.contact?.split('|')[0] || '';
                          setCurrentTeacher({ ...currentTeacher, contact: `${old}|${e.target.value}` });
                        }}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Email</label>
                      <input 
                        type="email" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentTeacher?.contact?.split('|')[0] || ''}
                        onChange={(e) => {
                          const old = currentTeacher?.contact?.split('|')[1] || '';
                          setCurrentTeacher({ ...currentTeacher, contact: `${e.target.value}|${old}` });
                        }}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Login ID (উজার আইডি) <span className="text-red-500">*</span></label>
                      <input 
                        type="text" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentTeacher?.loginId || ''}
                        required
                        placeholder="e.g. TCH001"
                        onChange={(e) => setCurrentTeacher({ ...currentTeacher, loginId: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">Password (পাসওয়ার্ড) <span className="text-red-500">*</span></label>
                      <input 
                        type="password" 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentTeacher?.password || ''}
                        required
                        placeholder="••••••••"
                        onChange={(e) => setCurrentTeacher({ ...currentTeacher, password: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Image URL</label>
                    <div className="flex gap-4">
                      <input 
                        type="text" 
                        className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                        value={currentTeacher?.image || ''}
                        placeholder="https://drive.google.com/file/d/..."
                        onChange={(e) => setCurrentTeacher({ ...currentTeacher, image: e.target.value })}
                      />
                      {currentTeacher?.image && (
                        <div className="w-12 h-12 rounded-lg bg-gray-100 overflow-hidden border border-gray-200">
                          <img 
                            src={getDirectImageUrl(currentTeacher.image)} 
                            alt="Preview" 
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/150")}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-6 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit" 
                      className="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all flex items-center justify-center gap-2"
                    >
                      <Check size={20} />
                      Save Teacher
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ManageTeachers;
