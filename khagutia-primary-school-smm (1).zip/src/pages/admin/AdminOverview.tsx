import React from 'react';
import { 
  Users, 
  UserPlus, 
  BookOpen, 
  Bell, 
  CreditCard, 
  TrendingUp,
  FileText,
  Settings,
  Image as ImageIcon,
  Download,
  GraduationCap
} from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

const AdminOverview = () => {
  const managementTiles = [
    { label: 'শিক্ষক ম্যানেজমেন্ট', path: '/admin/teachers', icon: <UserPlus size={32} />, color: 'bg-blue-600', sub: 'টিচার্স আইডি ওপেন ও কন্ট্রোল' },
    { label: 'ছাত্র-ছাত্রী ম্যানেজমেন্ট', path: '/admin/students', icon: <Users size={32} />, color: 'bg-green-600', sub: 'ক্লাস অনুযায়ী তালিকা ও আইডি' },
    { label: 'নোটিশ বোর্ড', path: '/admin/notices', icon: <Bell size={32} />, color: 'bg-orange-500', sub: 'নতুন নোটিশ আপলোড' },
    { label: 'ভর্তি তথ্য', path: '/admin/settings', icon: <FileText size={32} />, color: 'bg-red-500', sub: 'ভর্তি সংক্রান্ত তথ্য আপডেট' },
    { label: 'গ্যালারি ম্যানেজমেন্ট', path: '/admin/gallery', icon: <ImageIcon size={32} />, color: 'bg-purple-600', sub: 'ছবি ও ক্যাপশন আপলোড' },
    { label: 'প্রধান শিক্ষকের বাণী', path: '/admin/head-teacher', icon: <GraduationCap size={32} />, color: 'bg-indigo-600', sub: 'বাণী ও ছবি পরিবর্তন' },
    { label: 'সাইট সেটিংস', path: '/admin/settings', icon: <Settings size={32} />, color: 'bg-gray-700', sub: 'লোগো ও অন্যান্য ইনফো' },
    { label: 'ফলাফল আপলোড', path: '/admin/results', icon: <TrendingUp size={32} />, color: 'bg-teal-600', sub: 'বার্ষিক পরীক্ষার রেজাল্ট' },
  ];

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-gray-800">অ্যাডমিন কন্ট্রোল পোর্টাল</h2>
          <p className="text-gray-500 font-bold uppercase tracking-widest text-xs mt-1">Khagutia Primary School Dashboard</p>
        </div>
      </div>

      {/* Iconic Box Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {managementTiles.map((tile, i) => (
          <motion.div
            key={tile.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
          >
            <Link 
              to={tile.path}
              className="bg-white p-6 rounded-3xl shadow-sm hover:shadow-xl transition-all border border-gray-100 flex flex-col items-center text-center group cursor-pointer"
            >
              <div className={`${tile.color} text-white p-5 rounded-2xl mb-4 group-hover:scale-110 group-hover:rotate-3 transition-transform shadow-lg`}>
                {tile.icon}
              </div>
              <h3 className="text-lg font-black text-gray-800 mb-1">{tile.label}</h3>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{tile.sub}</p>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
         <h3 className="text-xl font-black text-gray-800 mb-6 flex items-center gap-2">
           <Download size={24} className="text-blue-600" />
           স্টুডেন্ট লিস্ট ডাউনলোড (ক্লাস অনুযায়ী)
         </h3>
         <div className="flex flex-wrap gap-4">
           {['Play', 'Nursery', 'One', 'Two', 'Three', 'Four', 'Five'].map(cls => (
             <button key={cls} className="px-6 py-3 bg-gray-50 hover:bg-blue-600 hover:text-white rounded-xl font-bold transition-all border border-gray-100 flex items-center gap-2">
               Class {cls}
               <Download size={16} />
             </button>
           ))}
         </div>
      </div>
    </div>
  );
};

const QuickActionBtn = ({ label, icon, color }: { label: string, icon: any, color: string }) => (
  <button className="flex flex-col items-center justify-center p-4 rounded-xl border border-gray-100 hover:border-blue-200 hover:bg-blue-50 transition-all group">
    <div className={`${color} mb-2 group-hover:scale-110 transition-transform`}>{icon}</div>
    <span className="text-xs font-bold text-gray-700">{label}</span>
  </button>
);

export default AdminOverview;
