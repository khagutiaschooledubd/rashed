import React, { useState, useEffect } from 'react';
import { FileText, Plus, Trash2, Search, TrendingUp, User, BookOpen, Hash, Award } from 'lucide-react';
import { getAll, createItem, deleteItem } from '../../services/api';
import { ExamResult, StudentProfile } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { where } from 'firebase/firestore';

const ManageResults = () => {
  const [results, setResults] = useState<ExamResult[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClass, setSelectedClass] = useState('All');
  
  const [newResult, setNewResult] = useState({
    studentId: '',
    studentName: '',
    rollNo: '',
    className: '',
    subject: '',
    marks: 0,
    grade: '',
    examName: 'Annual Exam 2026'
  });

  const classes = ['Nursery', 'Play', 'One', 'Two', 'Three', 'Four', 'Five'];
  const subjects = ['Bangla', 'English', 'Mathematics', 'Science', 'Social Science', 'Religion', 'Physical Education', 'Arts'];

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [resultsData, studentsData] = await Promise.all([
        getAll<ExamResult>('results'),
        getAll<StudentProfile>('students')
      ]);
      setResults(resultsData.sort((a, b) => b.createdAt?.seconds - a.createdAt?.seconds));
      setStudents(studentsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateGrade = (marks: number) => {
    if (marks >= 80) return 'A+';
    if (marks >= 70) return 'A';
    if (marks >= 60) return 'A-';
    if (marks >= 50) return 'B';
    if (marks >= 40) return 'C';
    if (marks >= 33) return 'D';
    return 'F';
  };

  const handleStudentChange = (studentId: string) => {
    const student = students.find(s => s.id === studentId);
    if (student) {
      setNewResult({
        ...newResult,
        studentId,
        studentName: student.name,
        rollNo: student.rollNo,
        className: student.className
      });
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newResult.studentId || !newResult.subject || !newResult.marks) return;

    try {
      const grade = calculateGrade(Number(newResult.marks));
      await createItem('results', {
        ...newResult,
        marks: Number(newResult.marks),
        grade,
        createdAt: new Date()
      });
      setIsAdding(false);
      setNewResult({
        studentId: '',
        studentName: '',
        rollNo: '',
        className: '',
        subject: '',
        marks: 0,
        grade: '',
        examName: 'Annual Exam 2026'
      });
      fetchData();
    } catch (error) {
      alert('Error adding result');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this record?')) return;
    try {
      await deleteItem('results', id);
      fetchData();
    } catch (error) {
      alert('Error deleting result');
    }
  };

  const filteredResults = results.filter(r => {
    const matchesSearch = r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         r.rollNo.includes(searchTerm) ||
                         r.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === 'All' || r.className === selectedClass;
    return matchesSearch && matchesClass;
  });

  return (
    <div className="p-6 max-w-7xl mx-auto font-bengali">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">পড়ালেখার ফলাফল ম্যানেজমেন্ট</h1>
          <p className="text-gray-500 font-medium">শিক্ষার্থীদের পরীক্ষার ফলাফল শ্রেণী ও বিষয় অনুযায়ী আপলোড করুন</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 bg-[#002147] text-white px-6 py-4 rounded-2xl font-bold hover:bg-blue-900 transition-all shadow-xl shadow-blue-100"
        >
          <Plus size={20} />
          ফলাফল যোগ করুন
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="নাম, রোল বা বিষয় দিয়ে খুঁজুন..." 
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select 
          className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold"
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
        >
          <option value="All">সকল শ্রেণী (All Classes)</option>
          {classes.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-white rounded-2xl animate-pulse border border-gray-100" />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="p-6 font-black text-gray-600 text-sm tracking-wider uppercase">শিক্ষার্থী</th>
                  <th className="p-6 font-black text-gray-600 text-sm tracking-wider uppercase">শ্রেণী ও রোল</th>
                  <th className="p-6 font-black text-gray-600 text-sm tracking-wider uppercase">বিষয়</th>
                  <th className="p-6 font-black text-gray-600 text-sm tracking-wider uppercase">নম্বর</th>
                  <th className="p-6 font-black text-gray-600 text-sm tracking-wider uppercase">গ্রেড</th>
                  <th className="p-6 font-black text-gray-600 text-sm tracking-wider uppercase">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence>
                  {filteredResults.map((result) => (
                    <motion.tr 
                      key={result.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors"
                    >
                      <td className="p-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">
                            <User size={18} />
                          </div>
                          <div>
                            <p className="font-bold text-gray-900">{result.studentName}</p>
                            <p className="text-xs text-gray-400">ID: {result.studentId.slice(-6).toUpperCase()}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-6">
                        <div className="space-y-1">
                          <span className="inline-block px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-bold rounded-lg uppercase">
                            Class {result.className}
                          </span>
                          <p className="text-sm font-bold text-gray-600">Roll: {result.rollNo}</p>
                        </div>
                      </td>
                      <td className="p-6">
                        <p className="font-bold text-gray-800">{result.subject}</p>
                        <p className="text-xs text-gray-400">{result.examName}</p>
                      </td>
                      <td className="p-6">
                        <span className="text-xl font-black text-gray-900">{result.marks}</span>
                      </td>
                      <td className="p-6">
                        <span className={`px-4 py-2 rounded-xl font-black text-sm ${
                          result.grade === 'A+' ? 'bg-green-100 text-green-700' :
                          result.grade === 'F' ? 'bg-red-100 text-red-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>
                          {result.grade}
                        </span>
                      </td>
                      <td className="p-6">
                        <button 
                          onClick={() => handleDelete(result.id!)}
                          className="p-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                        >
                          <Trash2 size={20} />
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
                {filteredResults.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-20 text-center">
                      <div className="flex flex-col items-center gap-4 text-gray-400">
                        <FileText size={64} className="opacity-10" />
                        <p className="text-xl font-bold">কোনো ফলাফলের তথ্য পাওয়া যায়নি</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Modal */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdding(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-3xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
            >
              <div className="p-10">
                <div className="flex items-center gap-4 mb-8">
                  <div className="p-4 bg-blue-50 text-blue-600 rounded-3xl">
                    <TrendingUp size={32} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-gray-900 leading-tight">নতুন ফলাফলের তথ্য যুক্ত করুন</h2>
                    <p className="text-gray-500 font-medium">নিচের তালিকায় শিক্ষার্থী নির্বাচন করে তথ্য পূরণ করুন</p>
                  </div>
                </div>

                <form onSubmit={handleAdd} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <User size={16} /> শিক্ষার্থী নির্বাচন করুন
                      </label>
                      <select 
                        required
                        className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                        value={newResult.studentId}
                        onChange={(e) => handleStudentChange(e.target.value)}
                      >
                        <option value="">শিক্ষার্থী সিলেক্ট করুন...</option>
                        {students.map(s => (
                          <option key={s.id} value={s.id}>
                            {s.name} (Class: {s.className}, Roll: {s.rollNo})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <BookOpen size={16} /> বিষয়
                      </label>
                      <select 
                        required
                        className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold"
                        value={newResult.subject}
                        onChange={(e) => setNewResult({ ...newResult, subject: e.target.value })}
                      >
                        <option value="">বিষয় সিলেক্ট করুন...</option>
                        {subjects.map(sub => <option key={sub} value={sub}>{sub}</option>)}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Award size={16} /> পরীক্ষার নাম
                      </label>
                      <input 
                        type="text" 
                        required
                        className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                        placeholder="e.g. Annual Exam 2026"
                        value={newResult.examName}
                        onChange={(e) => setNewResult({ ...newResult, examName: e.target.value })}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Hash size={16} /> প্রাপ্ত নম্বর
                      </label>
                      <input 
                        type="number" 
                        required
                        min="0"
                        max="100"
                        className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all text-xl font-black"
                        placeholder="0-100"
                        value={newResult.marks}
                        onChange={(e) => setNewResult({ ...newResult, marks: Number(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button 
                      type="button" 
                      onClick={() => setIsAdding(false)}
                      className="flex-1 px-8 py-5 bg-gray-100 text-gray-700 font-bold rounded-[1.5rem] hover:bg-gray-200 transition-all"
                    >
                      বাতিল করুন
                    </button>
                    <button 
                      type="submit" 
                      className="flex-1 px-8 py-5 bg-[#002147] text-white font-bold rounded-[1.5rem] hover:bg-blue-900 transition-all shadow-xl shadow-blue-100"
                    >
                      ফলাফল আপলোড করুন
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ManageResults;
