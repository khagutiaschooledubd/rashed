import React, { useState, useEffect } from 'react';
import { getById } from '../../services/api';
import { SiteSettings } from '../../types';
import { Save, Check, AlertCircle, UserCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { setDoc, doc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { getDirectImageUrl } from '../../lib/imageUtils';

const ManageHeadTeacher = () => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const data = await getById<SiteSettings>('settings', 'general');
    if (data) {
      setSettings(data);
    }
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    
    try {
      await setDoc(doc(db, 'settings', 'general'), settings);
      setMessage('Head Teacher\'s profile updated successfully!');
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      console.error(err);
      setMessage('Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="animate-pulse h-96 bg-gray-100 rounded-3xl"></div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-black text-gray-900 tracking-tight">প্রধান শিক্ষকের বাণী</h2>
          <p className="text-gray-500 font-medium font-bengali">প্রধান শিক্ষকের নাম, ছবি ও বাণী পরির্বতন করুন</p>
        </div>
      </div>

      {message && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl flex items-center gap-3 font-bold text-sm ${
            message.includes('successfully') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}
        >
          {message.includes('successfully') ? <Check size={18} /> : <AlertCircle size={18} />}
          {message}
        </motion.div>
      )}

      <form onSubmit={handleSave} className="space-y-6 font-bengali">
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
              <UserCircle size={24} />
            </div>
            <h3 className="text-xl font-bold text-gray-800">প্রধান শিক্ষকের প্রোফাইল</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">নাম (Name)</label>
              <input 
                type="text" 
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                value={settings?.headTeacherName || ''}
                onChange={(e) => setSettings({ ...settings!, headTeacherName: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">ছবি (Direct Image URL)</label>
              <div className="flex gap-4">
                <input 
                  type="text" 
                  className="flex-1 px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  value={settings?.headTeacherImage || ''}
                  placeholder="https://drive.google.com/..."
                  onChange={(e) => setSettings({ ...settings!, headTeacherImage: e.target.value })}
                />
                {settings?.headTeacherImage && (
                  <div className="w-14 h-14 rounded-2xl bg-gray-100 overflow-hidden border border-gray-200 shadow-sm">
                    <img 
                      src={getDirectImageUrl(settings.headTeacherImage)} 
                      alt="HT Preview" 
                      className="w-full h-full object-cover"
                      onError={(e) => (e.currentTarget.src = "https://via.placeholder.com/150?text=No+Image")}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">বাণী (Head Teacher's Message)</label>
            <textarea 
              className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 h-48 resize-none transition-all leading-relaxed"
              placeholder="প্রধান শিক্ষকের বাণী এখানে লিখুন..."
              value={settings?.headTeacherMessage || ''}
              onChange={(e) => setSettings({ ...settings!, headTeacherMessage: e.target.value })}
            ></textarea>
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <button 
            type="submit" 
            disabled={saving}
            className="bg-[#002147] hover:bg-blue-900 text-white px-12 py-4 rounded-2xl font-bold flex items-center gap-3 shadow-xl transition-all transform hover:-translate-y-1 disabled:bg-gray-400 disabled:transform-none group"
          >
            {saving ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <Save size={20} className="group-hover:scale-110 transition-transform" />
                তথ্য সেভ করুন
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ManageHeadTeacher;
