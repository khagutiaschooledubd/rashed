import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit,
  X,
  Check,
  Bell
} from 'lucide-react';
import { getAll, createItem, updateItem, deleteItem } from '../../services/api';
import { Notice } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { orderBy } from 'firebase/firestore';

const ManageNotices = () => {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentNotice, setCurrentNotice] = useState<Partial<Notice> | null>(null);

  useEffect(() => {
    loadNotices();
  }, []);

  const loadNotices = async () => {
    setLoading(true);
    const data = await getAll<Notice>('notices', [orderBy('date', 'desc')]);
    setNotices(data);
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentNotice) return;

    const data = {
      ...currentNotice,
      date: currentNotice.date || new Date()
    };

    if (currentNotice.id) {
      await updateItem('notices', currentNotice.id, data);
    } else {
      await createItem('notices', data);
    }
    
    setIsModalOpen(false);
    loadNotices();
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this notice?')) {
      await deleteItem('notices', id);
      loadNotices();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-gray-800">Manage Notices</h2>
          <p className="text-gray-500 font-medium">Post and manage school announcements</p>
        </div>
        <button 
          onClick={() => { setCurrentNotice({ date: new Date() }); setIsModalOpen(true); }}
          className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-transform hover:-translate-y-1"
        >
          <Plus size={20} />
          New Notice
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {loading ? (
          [1, 2, 3].map(i => <div key={i} className="h-24 bg-white animate-pulse rounded-xl border border-gray-100"></div>)
        ) : notices.map((notice) => (
          <div key={notice.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between group">
            <div className="flex items-center gap-6">
              <div className="w-12 h-12 rounded-xl bg-orange-50 flex items-center justify-center text-orange-500">
                <Bell size={24} />
              </div>
              <div>
                <h4 className="text-lg font-black text-gray-800">{notice.title}</h4>
                <p className="text-sm font-medium text-gray-500 line-clamp-1">{notice.content}</p>
              </div>
            </div>
            <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
               <button 
                 onClick={() => { setCurrentNotice(notice); setIsModalOpen(true); }}
                 className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
               >
                 <Edit size={18} />
               </button>
               <button 
                 onClick={() => handleDelete(notice.id)}
                 className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
               >
                 <Trash2 size={18} />
               </button>
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            ></motion.div>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-black text-gray-800">
                    {currentNotice?.id ? 'Edit Notice' : 'Post New Notice'}
                  </h3>
                  <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                    <X size={24} />
                  </button>
                </div>

                <form onSubmit={handleSave} className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Title</label>
                    <input 
                      type="text" 
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500"
                      value={currentNotice?.title || ''}
                      onChange={(e) => setCurrentNotice({ ...currentNotice, title: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
                    <select 
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500"
                      value={currentNotice?.category || ''}
                      onChange={(e) => setCurrentNotice({ ...currentNotice, category: e.target.value })}
                    >
                      <option value="General">General</option>
                      <option value="Admission">Admission</option>
                      <option value="Examination">Examination</option>
                      <option value="Holiday">Holiday</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Content</label>
                    <textarea 
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500 h-32 resize-none"
                      value={currentNotice?.content || ''}
                      onChange={(e) => setCurrentNotice({ ...currentNotice, content: e.target.value })}
                    ></textarea>
                  </div>

                  <div className="pt-6 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit" 
                      className="flex-1 py-3 bg-orange-500 text-white font-bold rounded-xl hover:bg-orange-600 shadow-lg shadow-orange-200 transition-all flex items-center justify-center gap-2"
                    >
                      <Check size={20} />
                      Post Notice
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ManageNotices;
