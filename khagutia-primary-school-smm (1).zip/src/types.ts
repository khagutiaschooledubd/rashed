export type UserRole = 'admin' | 'teacher' | 'student';

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  name: string;
  createdAt: any;
  photoURL?: string;
}

export interface TeacherProfile {
  id: string;
  uid?: string;
  name: string;
  designation: string;
  image: string;
  contact: string;
  address: string;
  loginId?: string;
  password?: string;
  classes: string[];
}

export interface StudentProfile {
  id: string;
  uid?: string;
  name: string;
  rollNo: string;
  className: string;
  section?: string;
  guardianName: string;
  guardianPhone: string;
  address?: string;
  image?: string;
  loginId?: string;
  password?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: any;
  category: string;
}

export interface HomeWork {
  id: string;
  teacherId: string;
  teacherName: string;
  className: string;
  subject: string;
  title: string;
  description: string;
  date: any;
}

export interface GalleryItem {
  id?: string;
  imageUrl: string;
  caption: string;
  createdAt: any;
}

export interface ExamResult {
  id?: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  className: string;
  subject: string;
  marks: number;
  grade: string;
  examName: string;
  createdAt: any;
}

export interface HeroSlide {
  image: string;
  title: string;
  subtitle: string;
}

export interface SiteSettings {
  schoolName: string;
  headTeacherMessage: string;
  headTeacherName: string;
  headTeacherImage: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  aboutText: string;
  aboutIntro?: string;
  aboutHistory?: string;
  aboutGoal?: string;
  aboutAchievement?: string;
  aboutVision?: string;
  aboutMission?: string;
  aboutImageUrl?: string;
  logoUrl?: string;
  bannerUrl?: string; // Kept for backward compatibility
  heroSlides?: HeroSlide[];
  facebookUrl?: string;
  youtubeUrl?: string;
  scrollingNotice?: string;
  govLogoUrl?: string;
}
