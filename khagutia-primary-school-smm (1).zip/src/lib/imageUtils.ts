export function getDirectImageUrl(url: string | undefined): string | undefined {
  if (!url) return url;

  // If it's already a direct googleusercontent link, return as is
  if (url.includes('googleusercontent.com')) return url;

  // Standard sharing link: https://drive.google.com/file/d/FILE_ID/view?usp=sharing
  // Alternative sharing link: https://drive.google.com/open?id=FILE_ID
  // Export link: https://drive.google.com/uc?id=FILE_ID
  // Also matches simple IDs
  
  const fileIdMatch = url.match(/(?:\/d\/|id=|drive\/folders\/|file\/d\/)([a-zA-Z0-9_-]{25,})/) || url.match(/^([a-zA-Z0-9_-]{25,})$/);
  const fileId = fileIdMatch ? fileIdMatch[1] : null;

  if (fileId) {
    // lh3.googleusercontent.com is very reliable for direct image serving
    return `https://lh3.googleusercontent.com/d/${fileId}`;
  }

  return url;
}
